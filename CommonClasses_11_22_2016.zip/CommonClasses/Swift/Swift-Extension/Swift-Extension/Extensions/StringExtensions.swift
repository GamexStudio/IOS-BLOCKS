//
//  UIView-ShortCuts.swift
//  Swift-Useful-Extensions
//
//  Created by Yin Xu on 6/9/14.
//  Copyright (c) 2014 YinXuApp. All rights reserved.
//
import CoreFoundation
import Foundation
import UIKit



extension String{
    var length:Int {return self.characters.count}
    
    //MARK:-  Capitalizes first character of String
    public var capitalizeFirst: String {
        var result = self
        result.replaceRange(startIndex...startIndex, with: String(self[startIndex]).capitalizedString)
        return result
    }
    
    //MARK:- Contain
    func containsString(s:String) -> Bool
    {
        if(self.rangeOfString(s) != nil)
        {
            return true
        }
        else
        {
            return false
        }
    }
    
    
    func containsString(s:String, compareOption: NSStringCompareOptions) -> Bool
    {
        if((self.rangeOfString(s, options: compareOption)) != nil)
        {
            return true
        }
        else
        {
            return false
        }
    }
    
    
    func containsOnlyLetters() -> Bool {
        let letterCharacterset = NSCharacterSet.letterCharacterSet().invertedSet
        return self.rangeOfCharacterFromSet(letterCharacterset) == nil
    }
    
    func containsOnlyNumbers() -> Bool {
        let letterCharacterset = NSCharacterSet(charactersInString: "0123456789").invertedSet
        return self.rangeOfCharacterFromSet(letterCharacterset) == nil
    }
   
    
    
    func containsOnlyNumbersWithDecimal() -> Bool {
        let letterCharacterset = NSCharacterSet(charactersInString: "-0123456789.").invertedSet
        return self.rangeOfCharacterFromSet(letterCharacterset) == nil
    }
    
    
    func containsOnlyNumbersWithDot() -> Bool {
        let letterCharacterset = NSCharacterSet(charactersInString: "0123456789").invertedSet
        return self.rangeOfCharacterFromSet(letterCharacterset) == nil
    }
    
    
    func containsOnlyNumbersWithDotAndBracket() -> Bool {
        let letterCharacterset = NSCharacterSet(charactersInString: "0123456789.()").invertedSet
        return self.rangeOfCharacterFromSet(letterCharacterset) == nil
    }
    
    func containsOnlyNumbersAndLetters() -> Bool {
        let letterCharacterset = NSCharacterSet.alphanumericCharacterSet().invertedSet
        return self.rangeOfCharacterFromSet(letterCharacterset) == nil
    }
    
    func isBeginsWith(string : String) -> Bool {
        return self.hasPrefix(string)
    }
    
    func isEndssWith(string : String) -> Bool {
        return self.hasSuffix(string)
    }
    
   
   //MARK:- Convert
    func intValue() -> Int {
        let scan = NSScanner(string: self)
        scan.charactersToBeSkipped = NSCharacterSet(charactersInString: "0123456789").invertedSet
        var val : Int32 = 0
        scan.scanInt(&val)
        return Int(val)
    }
    
    func floatValue() -> Float {
        let scan = NSScanner(string: self)
        scan.charactersToBeSkipped = NSCharacterSet(charactersInString: "0123456789.").invertedSet        
        var val : Float = 0
        scan.scanFloat(&val)
        return val
    }
    
    func doubleValue() -> Double {
        let scan = NSScanner(string: self)
        scan.charactersToBeSkipped = NSCharacterSet(charactersInString: "0123456789.").invertedSet
        var val : Double = 0
        scan.scanDouble(&val)
        return val
    }

   
    //MARK: - Validate
    
    func isValidEmail() -> Bool {
        
        let regex = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}"
        let emailTestPredicate = NSPredicate(format: "SELF MATCHES %@", regex)
        return emailTestPredicate.evaluateWithObject(self)
    }
    
    func isValid() -> Bool {
        if self.trim() == "" || self == "(null)" {
            return false
        }else {
            return true
        }
    }
    
    
    //MARK: - Trim
    func trimEnd() -> String {
        let string1 = "a" .stringByAppendingString(self).stringByTrimmingCharactersInSet(NSCharacterSet.whitespaceAndNewlineCharacterSet())
        return string1.substringFromIndex("a".endIndex)
    }
    
    
    func trimStart() -> String {
        var string1 = self.stringByAppendingString("a").stringByTrimmingCharactersInSet(NSCharacterSet.whitespaceAndNewlineCharacterSet())
        string1.removeRange(string1.rangeOfString("a")!)
        return string1
    }
    
    
    func trim() -> String {
        return self.stringByTrimmingCharactersInSet(NSCharacterSet.whitespaceAndNewlineCharacterSet())
    }
    
    func trimSpace() -> String {
        return self.stringByTrimmingCharactersInSet(NSCharacterSet.whitespaceCharacterSet())
    }
    
    
    //MARK: - Extracts URLS from String
    public var extractURLs: [NSURL] {
        var urls: [NSURL] = []
        let detector: NSDataDetector?
        do {
            detector = try NSDataDetector(types: NSTextCheckingType.Link.rawValue)
        } catch _ as NSError {
            detector = nil
        }
        
        let text = self
        
        if let detector = detector {
            detector.enumerateMatchesInString(text, options: [], range: NSRange(location: 0, length: text.characters.count), usingBlock: {
                (result: NSTextCheckingResult?, flags: NSMatchingFlags, stop: UnsafeMutablePointer<ObjCBool>) -> Void in
                if let result = result,
                    let url = result.URL {
                    urls.append(url)
                }
            })
        }
        
        return urls
    }
}


