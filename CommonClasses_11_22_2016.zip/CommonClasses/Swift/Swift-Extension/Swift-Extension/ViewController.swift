//
//  ViewController.swift
//  Swift-Extension
//
//  Created by Henryp on 16/05/16.
//  Copyright © 2016 Henryp. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    
        let x : Int = 25849624752;
        print(x.digits)
        
        let s : String = "wed223.2dae55"
        print(s.floatValue())
    }

}

