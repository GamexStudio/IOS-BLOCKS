//
//  ViewController.m
//  CommonClassesDemo
//
//  Created on 18/06/15.
//
//

#import "ViewController.h"
#import "CommonHeaders.h"
#import "SVProgressHUD.h"


@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    /*[UIImagePickerController imageWithSourceType:UIImagePickerControllerSourceTypeCamera DidFinish:^(UIImagePickerController *picker, NSDictionary *info) {
        if (info) {
            UIImage *image = [info valueForKey:UIImagePickerControllerOriginalImage];
            [imagView setImage:image];
        }
    }];*/
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
}



@end
