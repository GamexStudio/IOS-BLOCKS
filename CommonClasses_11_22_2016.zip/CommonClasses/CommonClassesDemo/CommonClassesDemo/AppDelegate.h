//
//  AppDelegate.h
//  CommonClassesDemo
//
//  Created on 18/06/15.
//
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

