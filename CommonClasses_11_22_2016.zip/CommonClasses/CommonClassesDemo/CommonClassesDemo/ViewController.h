//
//  ViewController.h
//  CommonClassesDemo
//
//  Created on 18/06/15.
//
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
{
    IBOutlet UITextView *txtView;
}

@end

