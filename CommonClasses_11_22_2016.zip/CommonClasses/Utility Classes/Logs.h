//
//  Logs.h
//  CommonClassesDemo
//
//  Created on 13/08/15.
//
//

#ifndef CommonClassesDemo_Logs_h
#define CommonClassesDemo_Logs_h

#pragma mark -  -------------------Print Log-------------------------
//DEBUG  Print Log mode , the current line
#ifdef DEBUG
#   define DLog(fmt, ...) NSLog((@"%s [Line %d] " fmt), __PRETTY_FUNCTION__, __LINE__, ##__VA_ARGS__);
#else
#   define DLog(...)
#endif

// NSLog,Debug Print log and the current number of rows mode
#if DEBUG
#define NSLog(FORMAT, ...) fprintf(stderr,"\nfunction:%s line:%d content:%s\n", __FUNCTION__, __LINE__, [[NSString stringWithFormat:FORMAT, ##__VA_ARGS__] UTF8String]);
#else
#define NSLog(FORMAT, ...) nil
#endif

//DEBUG  A warning print log mode , the current line and pop
#ifdef DEBUG
#   define ULog(fmt, ...)  { UIAlertView *alert = [[UIAlertView alloc] initWithTitle:[NSString stringWithFormat:@"%s\n [Line %d] ", __PRETTY_FUNCTION__, __LINE__] message:[NSString stringWithFormat:fmt, ##__VA_ARGS__]  delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil]; [alert show]; }
#else
#   define ULog(...)
#endif


//Print position , size
#ifdef DEBUG
#define DNSLogPoint(p) NSLog(@&quot;%f,%f&quot;, p.x, p.y);
#define DNSLogSize(p) NSLog(@&quot;%f,%f&quot;, p.width, p.height);
#define DNSLogRect(p) NSLog(@&quot;%f,%f,%f,%f&quot;, p.origin.x, p.origin.y, p.size.width, p.size.height,);
#else
#define DNSLogPoint(p);
#define DNSLogSize(p);
#define DNSLogRect(p);
#endif


//---------------------Print Log--------------------------

#endif
