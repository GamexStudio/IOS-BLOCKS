

#import "IAPHelper.h"

@interface IAPHelper () {
    RequestProductsSuccessBlock requestProductsSuccess;
    RequestProductsFailureBlock requestProductsFailure;
    
    PaymentTransactionSuccessBlock paymentTransactionSuccess;
    PaymentTransactionFailureBlock paymentTransactionFailure;
    
    RestoreTransactionSuccessBlock restoreTransationSuccess;
    RestoreTransactionFailureBlock restoreTransationFailure;
}

@end

@implementation IAPHelper

static IAPHelper *_sharedHelper;

#pragma mark - Shared instance

+ (IAPHelper *) sharedInstance {
    static IAPHelper *sharedInstance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sharedInstance = [[IAPHelper alloc] init];
    });
    return sharedInstance;
}

#pragma mark - Initialization

- (id)init {    
	if ((self = [super init])) {
        [[SKPaymentQueue defaultQueue] addTransactionObserver:self];
	}
    return self;
}

#pragma mark - 

- (void)buyProductWithProductIdentifier:(NSString *)productIdentifier success:(PaymentTransactionSuccessBlock)success failure:(PaymentTransactionFailureBlock)failure {
    
    __weak IAPHelper * objSelf = self;
    NSSet *set = [NSSet setWithObjects:productIdentifier,nil];
    [self requestProductsWithProductIdentifiers:set success:^(NSArray *products) {
        if([products count] > 0) {
            [objSelf addPayment:[products objectAtIndex:0] success:^(SKPaymentTransaction *transaction) {
                if(success) {
                    success(transaction);
                }
            } failure:^(SKPaymentTransaction *transaction,NSError *error) {
                if(failure) {
                    failure(transaction,error);
                }
            }];
        }
        else {
            if(failure) {
                failure(nil,nil);
            }
        }
    } failure:^(NSArray *products) {
        if(failure) {
            failure(nil,nil);
        }
    }];
}


#pragma mark - Product request and response

- (void)requestProductsWithProductIdentifiers:(NSSet *)productIdentifiers success:(RequestProductsSuccessBlock)success failure:(RequestProductsFailureBlock)failure; {
    requestProductsSuccess = [success copy];
    requestProductsFailure = [failure copy];
    _request = [[SKProductsRequest alloc] initWithProductIdentifiers:productIdentifiers];
    _request.delegate = self;
    [_request start];
}

- (void)productsRequest:(SKProductsRequest *)request didReceiveResponse:(SKProductsResponse *)response {
    _request = nil;
    if([response.products count]) {
        [self callRequestProductsCompletion:YES products:response.products];
    }
    else {
        [self callRequestProductsCompletion:NO products:nil];
    }
}

#pragma mark - Add Payment

- (void)addPayment:(SKProduct *)product success:(PaymentTransactionSuccessBlock)success failure:(PaymentTransactionFailureBlock)failure {
    paymentTransactionSuccess = [success copy];
    paymentTransactionFailure = [failure copy];
    SKPayment *payment = [SKPayment paymentWithProduct:product];
    [[SKPaymentQueue defaultQueue] addPayment:payment];
}

#pragma mark - Restore Purchse

- (void)restoreTranscationWithSuccess:(RestoreTransactionSuccessBlock)success failure:(RestoreTransactionFailureBlock)failure  {
    restoreTransationSuccess = [success copy];
    restoreTransationFailure = [failure copy];
    [[SKPaymentQueue defaultQueue] restoreCompletedTransactions];
}

#pragma mark - Payment transaction Delegate

- (void)paymentQueue:(SKPaymentQueue *)queue updatedTransactions:(NSArray *)transactions {
    [transactions enumerateObjectsUsingBlock:^(SKPaymentTransaction *transaction, NSUInteger idx, BOOL *stop) {
        switch (transaction.transactionState) {
            case SKPaymentTransactionStatePurchased:
                [[SKPaymentQueue defaultQueue] finishTransaction: transaction];
                [self callPaymentTransactionCompletion:YES transaction:transaction error:nil];
                break;
            case SKPaymentTransactionStateFailed: {
                [[SKPaymentQueue defaultQueue] finishTransaction: transaction];
                [self callPaymentTransactionCompletion:NO transaction:transaction error:transaction.error];
                break;
            }
            case SKPaymentTransactionStateRestored:
            default:
                break;
        }
    }];
}

- (void)paymentQueueRestoreCompletedTransactionsFinished:(SKPaymentQueue *)queue {
    NSError *error = [NSError errorWithDomain:@"Error" code:1234 userInfo:@{NSLocalizedDescriptionKey:@"No Products Found"}];

    [self callRestoreTranscationCompletion:[queue.transactions count] ? YES : NO transactions:queue.transactions error:error];
}

- (void)paymentQueue:(SKPaymentQueue *)queue restoreCompletedTransactionsFailedWithError:(NSError *)error {
    [self callRestoreTranscationCompletion:NO transactions:queue.transactions error:error];
}

#pragma mark - call Completion Block

- (void)callRestoreTranscationCompletion:(BOOL)success transactions:(NSArray *)transactions error:(NSError *)error{
    if(success) {
        if(restoreTransationSuccess) {
            restoreTransationSuccess(transactions);
            restoreTransationSuccess = nil;
        }
    }
    else {
        if(restoreTransationFailure) {
            restoreTransationFailure(transactions,error);
            restoreTransationFailure = nil;
        }
    }
}

- (void)callPaymentTransactionCompletion:(BOOL)success transaction:(SKPaymentTransaction *)transaction error:(NSError *)error{
    if(success) {
        if(paymentTransactionSuccess) {
            paymentTransactionSuccess(transaction);
        }
    }
    else {
        if(paymentTransactionFailure) {
            paymentTransactionFailure(transaction,error);
        }
    }
}

- (void)callRequestProductsCompletion:(BOOL)success products:(NSArray *)products {
    if(success) {
        if(requestProductsSuccess) {
            requestProductsSuccess(products);
            requestProductsSuccess = nil;
        }
    }
    else {
        if(requestProductsFailure) {
            requestProductsFailure(products);
            requestProductsFailure = nil;
        }
    }
}

@end
