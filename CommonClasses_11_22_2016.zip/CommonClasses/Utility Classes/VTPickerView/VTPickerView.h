//
//  VTPickerView.h
//
//  Created on 08/12/14.
//  Copyright (c) 2014. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "VTMonthYearPicker.h"

typedef NS_ENUM(NSInteger, VTDatePickerMode) {
    VTDatePickerModeTime,
    VTDatePickerModeDate,
    VTDatePickerModeDateAndTime,
    VTDatePickerModeCountDownTimer,
    VTDatePickerModeMonthYear,
};

@protocol VTPickerDelegate;

@interface PItem : NSObject
@property (nonatomic, assign) NSInteger ID;
@property (nonatomic, strong) NSString *title;
@end

typedef void(^vtPickerdidTapDone)(id obj);
typedef void(^vtPickerdidTapCancel)();

@interface VTPickerView : UIView<UIPickerViewDataSource, UIPickerViewDelegate>
{
    IBOutlet UIButton *btnCancel;
    IBOutlet UIButton *btnDone;
    IBOutlet UILabel *lblTitle;
}

@property (nonatomic, assign) id<VTPickerDelegate> delegate;
@property (nonatomic, assign) NSInteger selectedIndex;

@property (nonatomic, strong) NSString *title;
@property (nonatomic, strong) IBOutlet UIView *pickerContainer;
@property (nonatomic, strong) IBOutlet UIPickerView *pickerView;
@property (nonatomic, strong) UIDatePicker *datePicker;
@property (nonatomic, strong) VTMonthYearPicker *monthYearPicker;
@property (nonatomic) VTDatePickerMode datePickerMode;

- (id)initWithFrame:(CGRect)frame;
- (id)initWithDatePickerType:(VTDatePickerMode)datePickerMode;
- (void)setItemWithStringArray:(NSArray *)arrItems;
- (void)showInView :(UIView *)targetView ;
- (void)showInView :(UIView *)targetView withDoneTappedBlock:(vtPickerdidTapDone)doneBlock withCancelTappedBlock:(vtPickerdidTapCancel)cancelBlock;

@property (nonatomic, copy) vtPickerdidTapDone pickerDidTapDone;
@property (nonatomic, copy) vtPickerdidTapCancel pickerDidTapCancel;

@end

@protocol VTPickerDelegate <NSObject>

@optional
- (void)vtPickerdidTapCancel:(VTPickerView*)pickerView;
- (void)vtPickerdidTapDone:(VTPickerView*)pickerView WithItem:(PItem *)item;
- (void)vtPickerdidTapDone:(VTPickerView*)pickerView selectedDate:(NSDate *)date;// call only when (- (id)initWithDatePickerType:(VTDatePickerMode)datePickerMode) called to init


@end