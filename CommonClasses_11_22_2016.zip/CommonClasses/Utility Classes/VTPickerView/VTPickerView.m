//
//  VTPickerView.m
//
//  Created on 08/12/14.
//  Copyright (c) 2014. All rights reserved.
//

#import "VTPickerView.h"
#import "NSDate+Utilities.h"
#import "UIView+Size.h"
#import "UIView+SubView.h"
#import "TCCustomFont.h"

@implementation PItem
- (instancetype)initWithID:(NSInteger)ID Title:(NSString *)title{
    self = [super init];
    self.ID = ID;
    self.title = title;
    return self;
}

@end



#pragma mark - VTPickerView

@interface VTPickerView()
@property (nonatomic, strong) NSMutableArray *arrItems;
@end

@implementation VTPickerView
- (instancetype)init {
    self = [super initWithFrame:CGRectZero];
    return self;
}

- (id)initWithFrame:(CGRect)frame {
    
    VTPickerView *view = [[[NSBundle mainBundle] loadNibNamed:@"VTPickerView" owner:self options:nil] objectAtIndex:0];
    self = view;
    [view setFrame:frame];
    [view initializeOnce];
    return view;
}

- (id)initWithDatePickerType:(VTDatePickerMode)datePickerMode {
    VTPickerView *selfView = [self initWithFrame:CGRectZero];
    _datePickerMode = datePickerMode;
    
    if (datePickerMode == VTDatePickerModeMonthYear) {
        _monthYearPicker = [[VTMonthYearPicker alloc] initWithFrame:selfView.pickerView.frame];
        [self.monthYearPicker setupMinYear:[[NSDate date]year] maxYear:[[NSDate date]year] + 20];
        [[selfView.pickerView superview] addSubview:self.monthYearPicker];
        
    }else {
        
    }
    return selfView;
}

- (void)initializeOnce {
    _arrItems = [[NSMutableArray alloc]init];
}

- (void)setTitle:(NSString *)title {
    _title = title;
      [lblTitle setText:title];
}

- (void)setItemWithStringArray:(NSArray *)arrItems {
    [self.arrItems removeAllObjects];
    [arrItems enumerateObjectsUsingBlock:^(id obj, NSUInteger idx, BOOL *stop) {
        PItem *item = [[PItem alloc]initWithID:idx Title:obj];
        [self.arrItems addObject:item];
    }];
    
    [_pickerView reloadAllComponents];
}

- (void)setItemsWithPItemClassArray:(NSArray *)arrItems {
    [self.arrItems removeAllObjects];
    [self.arrItems addObjectsFromArray:arrItems];
    [_pickerView reloadAllComponents];
}

- (void)setSelectedIndex:(NSInteger)selectedIndex {
    if (selectedIndex > -1 && selectedIndex < self.arrItems.count) {
        _selectedIndex = selectedIndex;
        [_pickerView selectRow:selectedIndex inComponent:0 animated:NO];
    }
}

#pragma mark - Show

- (void)showInView :(UIView *)targetView {
    [targetView addSubview:self];
    [self setFrame:targetView.bounds];
    [self setY:targetView.height];
    [targetView setClipsToBounds:true];
    _pickerView.delegate = self;
    _pickerView.dataSource = self;
    [_pickerView reloadAllComponents];
    
    [UIView animateWithDuration:0.5 animations:^{
        [self setY:targetView.height - self.height];
    }];
}

- (void)showInView :(UIView *)targetView withDoneTappedBlock:(vtPickerdidTapDone)doneBlock withCancelTappedBlock:(vtPickerdidTapCancel)cancelBlock {
    [self showInView:targetView];
    _pickerDidTapDone = [doneBlock copy];
    _pickerDidTapCancel = [cancelBlock copy];
}
#pragma mark - UIButton Event 

- (IBAction)btnCancelTapped:(UIButton *)sender {
    [self removeFromSuperview:kAnimateFromBottom duration:0.5 completion:nil];
    if(_pickerDidTapCancel) {
        _pickerDidTapCancel();
    }
    if ([self.delegate respondsToSelector:@selector(vtPickerdidTapCancel:)]) {
        [self.delegate vtPickerdidTapCancel:self];
    }
}

- (IBAction)btnDoneTapped:(UIButton *)sender {
    if (self.datePickerMode == VTDatePickerModeMonthYear) {
        if(_pickerDidTapDone) {
            _pickerDidTapDone(self.monthYearPicker.date);
        }
        if ([self.delegate respondsToSelector:@selector(vtPickerdidTapDone:selectedDate:)]) {
            [self.delegate vtPickerdidTapDone:self selectedDate:self.monthYearPicker.date];
        }
    }else{
        if(self.selectedIndex < self.arrItems.count) {
            PItem *item = [self.arrItems objectAtIndex:self.selectedIndex];
            if(_pickerDidTapDone) {
                _pickerDidTapDone(item);
            }
            if ([self.delegate respondsToSelector:@selector(vtPickerdidTapDone:WithItem:)]) {
                [self.delegate vtPickerdidTapDone:self WithItem:item];
            }
        }
    }
    
    [self removeFromSuperview:kAnimateFromBottom duration:0.5 completion:nil];
}

#pragma mark - UIPicker Delagate
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView {
    return 1;
}

- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component {
    return self.arrItems.count;
}

- (CGFloat)pickerView:(UIPickerView *)pickerView widthForComponent:(NSInteger)component {
    return pickerView.width;
}

- (CGFloat)pickerView:(UIPickerView *)pickerView rowHeightForComponent:(NSInteger)component {
    return 45;
}

- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component {
     return [(PItem *)[self.arrItems objectAtIndex:row] title];
}
/*
- (UIView *)pickerView:(UIPickerView *)pickerView viewForRow:(NSInteger)row forComponent:(NSInteger)component reusingView:(nullable UIView *)view {
//    if(!view) {
        view = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, pickerView.width, 45)];
//    }
    [((UILabel *)view) setText:[(PItem *)[self.arrItems objectAtIndex:row] title]];
    [view setBackgroundColor:[UIColor redColor]];
    return view;
}
*/
/*
- (NSAttributedString *)pickerView:(UIPickerView *)pickerView attributedTitleForRow:(NSInteger)row forComponent:(NSInteger)component {
    
    NSMutableAttributedString *str = [[NSMutableAttributedString alloc]initWithString:[(PItem *)[self.arrItems objectAtIndex:row] title]  attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:22],NSForegroundColorAttributeName:[UIColor blackColor]}];
    return str;
}
*/
- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component {
    self.selectedIndex = row;
}
@end
