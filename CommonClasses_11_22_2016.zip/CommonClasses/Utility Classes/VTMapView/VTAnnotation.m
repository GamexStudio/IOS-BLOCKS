

#import "VTAnnotation.h"
#import "NSString+Category.h"

@implementation VTAnnotation

+ (VTAnnotation *) annotationWithLatitude:(double) latitude longitude:(double)longitude title:(NSString*) title subTitle:(NSString*) subTitle defaultImage:(UIImage *) defaultImage selctedImage:(UIImage *) selectedImage annotationId:(NSString *) _id canShowCallout:(BOOL) canShow
{
    CLLocationCoordinate2D  coordinate = CLLocationCoordinate2DMake(latitude, longitude);
    return [self annotationWithCoordinate:coordinate
                                title:title
                             subTitle:subTitle
                         defaultImage:defaultImage
                         selctedImage:selectedImage
                         annotationId:_id
                       canShowCallout:canShow
                                ];
}

+ (VTAnnotation*) annotationWithCoordinate:(CLLocationCoordinate2D) coordinate title:(NSString*) title subTitle:(NSString*) subTitle defaultImage:(UIImage *) defaultImage selctedImage:(UIImage *) selectedImage annotationId:(NSString *) _id canShowCallout:(BOOL) canShow
{
    if (CLLocationCoordinate2DIsValid(coordinate))
    {
        VTAnnotation *annotation = [[VTAnnotation alloc] init];
        annotation.coordinate = coordinate;
        
        // Set Title
        if (![title isValid]) {
            annotation.title = title;
        }
        
        // Set Sub Title
        if (![subTitle isValid]) {
            annotation.subtitle = subTitle;
        }
        
        // Set Default Image
        if (defaultImage != nil) {
            annotation.defaultImage = defaultImage;
        }
        
        // Set Selected Image
        if (selectedImage != nil) {
            annotation.selectedImage = selectedImage;
        } else {
            annotation.selectedImage = nil;
        }
        
        // Set ID
        if (![_id isValid]) {
            annotation.ID = _id;
        } else {
            annotation.ID = nil;
        }
        
        // Set Call boolean
        annotation.canShowCallout = canShow;
        
        return annotation;
    }
    else
    {
        NSLog(@"Annotation Location Not Valid");
        return nil;
    }
}

@end
