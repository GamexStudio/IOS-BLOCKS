

#import "VTMapView.h"
#import "CommonHeaders.h"

#define DEFAULT_PIN_IMAGE [UIImage imageNamed:@"default_pin"]
#define SELECTED_PIN_IMAGE [UIImage imageNamed:@"selected_pin"]

#define MINIMUM_ZOOM_ARC 0.014 //approximately 1 miles (1 degree of arc ~= 69 miles)
#define ANNOTATION_REGION_PAD_FACTOR 1.15
#define MAX_DEGREES_ARC 360


#define USER_LOCATION_TITLE @"Current Location"

@interface VTMapView() <UIGestureRecognizerDelegate>

@property (nonatomic, retain) NSArray* routes;
@property (nonatomic, readwrite) BOOL isUpdatingRoutes;

@end


@implementation VTMapView

@synthesize vtMapDelegate = _vtMapDelegate;

#pragma mark - Init

-(instancetype)init
{
    if (self = [super init])
    {
        [self loadDefaultsParameters];
    }
    return self;
}

-(instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame])
    {
        [self loadDefaultsParameters];
    }
    return self;
}

-(instancetype)initWithCoder:(NSCoder *)aDecoder
{
    if (self = [super initWithCoder:aDecoder])
    {
        [self loadDefaultsParameters];
    }
    return self;
}

-(void)awakeFromNib
{
    [super awakeFromNib];

    [self loadDefaultsParameters];
}

#pragma setup default option

-(void)loadDefaultsParameters
{
    self.delegate = self;

    self.trackUserLocation = NO;

    // Add a pinch gesture recognizer
    UIPinchGestureRecognizer *pinchRecognizer = [[UIPinchGestureRecognizer alloc] initWithTarget:self action:@selector(handlePinchGesture:)];
    pinchRecognizer.delegate = self;
    [self addGestureRecognizer:pinchRecognizer];

}

#pragma mark - Map View Delegate

-(MKAnnotationView *)mapView:(MKMapView *)mV viewForAnnotation:(id <MKAnnotation>)annotation
{
    MKAnnotationView *pinView = nil;
    if(annotation != self.userLocation)
    {
        static NSString *defaultPinID = @"com.invasivecode.pin";
        pinView = (MKAnnotationView *)[self dequeueReusableAnnotationViewWithIdentifier:defaultPinID];
        if (pinView == nil) {
            pinView = [[MKAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:defaultPinID];
        }
        else {
            pinView.annotation = annotation;
        }
        pinView.rightCalloutAccessoryView = [UIButton buttonWithType:UIButtonTypeDetailDisclosure];
        [pinView.rightCalloutAccessoryView setHidden:YES];
        [self formatAnnotationView:pinView forMapView:mV];
    }
    else
    {
        [self.userLocation setTitle:USER_LOCATION_TITLE];
    }
    return pinView;
}

- (void)mapView:(MKMapView *)mapView didSelectAnnotationView:(MKAnnotationView *)view
{
    [self formatAnnotationView:view forMapView:mapView];
    if ([_vtMapDelegate respondsToSelector:@selector(didSelectAnnotationView:forMapView:)])
    {
        [_vtMapDelegate didSelectAnnotationView:(VTAnnotation *)view.annotation forMapView:mapView];
    }
}

- (void)mapView:(MKMapView *)mapView didDeselectAnnotationView:(MKAnnotationView *)view
{
    [self formatAnnotationView:view forMapView:mapView];
    if ([_vtMapDelegate respondsToSelector:@selector(didDeselectAnnotationView:forMapView:)])
    {
        [_vtMapDelegate didDeselectAnnotationView:(VTAnnotation *)view.annotation forMapView:mapView];
    }
}
/*
- (MKOverlayView *)mapView:(MKMapView *)mapView viewForOverlay:(id)overlay
{
    if ([overlay isKindOfClass:[VTPolyline class]])
    {
        MKPolylineView* aView = [[MKPolylineView alloc]initWithPolyline:(VTPolyline*)overlay] ;
        aView.strokeColor = [((VTPolyline *) overlay).lineColor colorWithAlphaComponent:((VTPolyline *) overlay).lineAlpha];
        aView.lineWidth = ((VTPolyline *) overlay).lineWidth;
        return aView;
    }
    return nil;
}
*/

- (MKOverlayRenderer *)mapView:(MKMapView *)mapView rendererForOverlay:(id <MKOverlay>)overlay {
    if ([overlay isKindOfClass:[VTPolyline class]])
    {
        MKPolylineRenderer* aRenderer = [[MKPolylineRenderer alloc]initWithPolyline:(VTPolyline*)overlay] ;
        aRenderer.strokeColor = [((VTPolyline *) overlay).lineColor colorWithAlphaComponent:((VTPolyline *) overlay).lineAlpha];
        aRenderer.lineWidth = ((VTPolyline *) overlay).lineWidth;
        return aRenderer;
    }
    return nil;
}

- (void)mapView:(MKMapView *)mapView didUpdateUserLocation:(MKUserLocation *)userLocation
{
    if (_trackUserLocation)
    {
        [self setCurrentLocation:nil];
    }
}

- (void)mapView:(MKMapView *)mapView annotationView:(MKAnnotationView *)view calloutAccessoryControlTapped:(UIControl *)control {
    if([_vtMapDelegate respondsToSelector:@selector(calloutAccessoryControlTapped:mapView:annotationView:)]) {
        [_vtMapDelegate calloutAccessoryControlTapped:control mapView:mapView annotationView:view];
    }
}

- (void)reloadPin {
    MKMapView *aMapView = self;

    for (id <MKAnnotation>annotation in aMapView.annotations) {
        // if it's the user location, just return nil.
        if ([annotation isKindOfClass:[MKUserLocation class]])
            return;

        // handle our custom annotations
        if ([annotation isKindOfClass:[VTAnnotation class]])
        {
            // try to retrieve an existing pin view first
            MKAnnotationView *pinView = [aMapView viewForAnnotation:annotation];
            //Format the pin view
            [self formatAnnotationView:pinView forMapView:aMapView];
        }
    }
}

#pragma mark - Pinch Guesture Handler

// Handle Map View Gesture
- (void)handlePinchGesture:(UIPinchGestureRecognizer *)pinchRecognizer {
    if (pinchRecognizer.state != UIGestureRecognizerStateChanged) {
        return;
    }

    MKMapView *aMapView = (MKMapView *)pinchRecognizer.view;

    for (id <MKAnnotation>annotation in aMapView.annotations) {
        // if it's the user location, just return nil.
        if ([annotation isKindOfClass:[MKUserLocation class]])
            return;

        // handle our custom annotations
        if ([annotation isKindOfClass:[VTAnnotation class]])
        {
            // try to retrieve an existing pin view first
            MKAnnotationView *pinView = [aMapView viewForAnnotation:annotation];
            //Format the pin view
            [self formatAnnotationView:pinView forMapView:aMapView];
        }
    }
}

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)otherGestureRecognizer {
    return YES;
}

#pragma mark - Map Annotation Extentions

// Add Annotation in Map View

- (VTAnnotation *) addAnnotationForLatitude:(double) latitude longitude:(double)longitude title:(NSString*) title subTitle:(NSString*) subTitle defaultImage:(UIImage *) defaultImage selctedImage:(UIImage *) selectedImage annotationId:(NSString *) _id canShowCallout:(BOOL) canShow
{
    CLLocationCoordinate2D  coordinate = CLLocationCoordinate2DMake(latitude, longitude);
    return [self addAnnotationWithCoordinate:coordinate
                                title:title
                             subTitle:subTitle
                         defaultImage:defaultImage
                         selctedImage:selectedImage
                         annotationId:_id
                       canShowCallout:canShow];
}


- (VTAnnotation *) addAnnotationWithCoordinate:(CLLocationCoordinate2D) coordinate title:(NSString*) title subTitle:(NSString*) subTitle defaultImage:(UIImage *) defaultImage selctedImage:(UIImage *) selectedImage annotationId:(NSString *) _id canShowCallout:(BOOL) canShow
{
    if (CLLocationCoordinate2DIsValid(coordinate))
    {
        VTAnnotation *annotation = [[VTAnnotation alloc] init];
        annotation.coordinate = coordinate;

        // Set Title
        if (![title isEmptyOrWhitespace]) {
            annotation.title = title;
        }

        // Set Sub Title
        if (![subTitle isEmptyOrWhitespace]) {
            annotation.subtitle = subTitle;
        }

        // Set Default Image
        if (defaultImage != nil) {
            annotation.defaultImage = defaultImage;
        } else {
            annotation.defaultImage = DEFAULT_PIN_IMAGE;
        }

        // Set Selected Image
        if (selectedImage != nil) {
            annotation.selectedImage = selectedImage;
        } else {
            annotation.selectedImage = nil;
        }

        // Set ID
        if (![_id isEmptyOrWhitespace]) {
            annotation.ID = _id;
        } else {
            annotation.ID = nil;
        }

        // Set Call boolean
        annotation.canShowCallout = canShow;

        [self addAnnotation:annotation];
        return annotation;
    }
    else
    {
        NSLog(@"Annotation Location Not Valid");
        return nil;
    }
}

// resize annotation and callout view.
- (void)formatAnnotationView:(MKAnnotationView *)pinView forMapView:(MKMapView *)aMapView
{
    if (pinView && pinView.annotation != self.userLocation)
    {
        //double zoomLevel = [aMapView zoomLevel];
       // double scale = -1 * sqrt((double)(1 - pow((zoomLevel/20.0), 1.0))) + 1.1;
        // This is a circular scale function where at zoom level 0 scale is 0.1 and at zoom level 20 scale is 1.1

        pinView.canShowCallout = ((VTAnnotation *)pinView.annotation).canShowCallout;

        // Option #1
       // pinView.transform = CGAffineTransformMakeScale(scale, scale);

        // Option #2

        UIImage *pinImage = nil;
        if (pinView.selected) {
            if (((VTAnnotation *)pinView.annotation).selectedImage != nil) {
                pinImage = ((VTAnnotation *)pinView.annotation).selectedImage;
            } else {
                pinImage = ((VTAnnotation *)pinView.annotation).defaultImage;
            }
        } else {
            pinImage = ((VTAnnotation *)pinView.annotation).defaultImage;
        }

       // pinView.image = [pinImage resizedImage:CGSizeMake(pinImage.size.width * scale, pinImage.size.height * scale) interpolationQuality:kCGInterpolationHigh];
        pinView.image = pinImage;
    }
}

- (NSString *) getUniqueAnnotationId
{
    NSInteger maxAnnotationId = 1;
    for (VTAnnotation * annotation in self.annotations) {
        NSInteger annotationId = [annotation.ID integerValue];
        if (maxAnnotationId < annotationId) {
            maxAnnotationId = annotationId;
        }
    }
    return [NSString stringWithFormat:@"%ld",(long)(maxAnnotationId+1)];
}

- (VTAnnotation *) getAnnotationForID:(NSString *) _id
{
    for (VTAnnotation * annotation in self.annotations) {
        if ([annotation.ID isEqualToString:_id]) {
            return annotation;
        }
    }
    return nil;
}

- (VTAnnotation *) getAnnotationForLatitude:(double) latitude longitute:(double) longitide
{
    for (VTAnnotation * annotation in self.annotations) {
        if (annotation.coordinate.latitude == latitude &&
            annotation.coordinate.longitude == longitide)
        {
            return annotation;
        }
    }
    return nil;
}

- (void) changeAnnotationLocation:(CLLocation *)location forAnnotationId:(NSString *)_id animation:(BOOL) animation completion:(VTAnnotationLocationChange) changed
{
    [self getAnnotationForID:_id].coordinate = location.coordinate;
    [self setCenterCoordinate:location.coordinate
                    zoomLevel:[self zoomLevel]
                     animated:animation];

    if (changed) {
        changed([self getAnnotationForID:_id]);
    }
}

#pragma mark - Map Overlay Extentions

- (void) removeAllPaths
{
    for (id path in self.overlays)
    {
        if ([path isKindOfClass:[VTPolyline class]])
        {
            [self removeOverlay:path];
        }
    }
}

- (void) removePathForSourceId:(NSString *)sourceId destinationId:(NSString *)destinationId
{
    for (id path in self.overlays)
    {
        if ([path isKindOfClass:[VTPolyline class]])
        {
            if ([((VTPolyline *) path).sourceId isEqualToString:sourceId] &&
                [((VTPolyline *) path).destinationId isEqualToString:destinationId])
            {
                [self removeOverlay:path];
            }
        }
        else
        {
            NSLog(@"This method only remove TVPolyline path");
        }
    }
}

#pragma mark - Show Route with Map Kit API.

- (void) drawPathFromSourceAnnotation:(VTAnnotation *) source destinationAnnotation:(VTAnnotation *) destination attribute:(NSDictionary *) attributes completion:(VTMapKitAPIRouteCompletion)completion
{
    [self showRouteUsingMapKitAPIFromSource:source toDestination:destination attribute:attributes completion:completion];
}

- (void) drawPathFromSourceLocation:(CLLocation *) source destinationLocation:(CLLocation *) destination attribute:(NSDictionary *) attributes completion:(VTMapKitAPIRouteCompletion)completion
{
    [self showRouteUsingMapKitAPIFromSource:source toDestination:destination attribute:attributes completion:completion];
}

- (void) showRouteUsingMapKitAPIFromSource:(id)source toDestination:(id)destination attribute:(NSDictionary *) attributes completion:(VTMapKitAPIRouteCompletion)completion
{
    if ([self isObjectValidSource:source andDestination:destination])
    {
        MKPlacemark *sourcePlacemark = [[MKPlacemark alloc] initWithCoordinate:[self get2DCoordinateForObject:source] addressDictionary:[NSDictionary dictionaryWithObjectsAndKeys:@"",@"", nil]];

        MKMapItem *srcMapItem = [[MKMapItem alloc]initWithPlacemark:sourcePlacemark];
        [srcMapItem setName:@""];

        MKPlacemark *destinationPlacemark = [[MKPlacemark alloc]initWithCoordinate:[self get2DCoordinateForObject:destination] addressDictionary:[NSDictionary dictionaryWithObjectsAndKeys:@"",@"", nil] ];

        MKMapItem *distMapItem = [[MKMapItem alloc]initWithPlacemark:destinationPlacemark];
        [distMapItem setName:@""];

        MKDirectionsRequest *request = [[MKDirectionsRequest alloc]init];
        [request setSource:srcMapItem];
        [request setDestination:distMapItem];
        [request setTransportType:MKDirectionsTransportTypeWalking | MKDirectionsTransportTypeAutomobile];

        MKDirections *direction = [[MKDirections alloc]initWithRequest:request];

        [direction calculateDirectionsWithCompletionHandler:^(MKDirectionsResponse *response, NSError *error) {

            NSArray *arrRoutes = [response routes];

            if (arrRoutes != nil && [arrRoutes count] > 0)
            {
                [arrRoutes enumerateObjectsUsingBlock:^(id obj, NSUInteger idx, BOOL *stop) {

                    MKRoute *rout = obj;
                    
                    VTPolyline *line = [VTPolyline polylineWithPoints:rout.polyline.points count:rout.polyline.pointCount];
                    line.sourceId = [self getPolylineIdForObject:source];
                    line.destinationId = [self getPolylineIdForObject:destination];

                    if (attributes != nil) {
                        line.lineColor = [attributes polyLineColor];
                        line.lineWidth = [attributes polyLineWidth];
                        line.lineAlpha = [attributes polyLineAlpha];
                    }

                    [self addOverlay:line];

                    NSLog(@"Rout Name : %@",rout.name);
                    NSLog(@"Total Distance (in Meters) :%f",rout.distance);

                    NSArray *steps = [rout steps];

                    NSLog(@"Total Steps : %lu",(unsigned long)[steps count]);

                    [steps enumerateObjectsUsingBlock:^(id obj, NSUInteger idx, BOOL *stop) {
                        NSLog(@"Rout Instruction : %@",[obj instructions]);
                        NSLog(@"Rout Distance : %f",[obj distance]);
                    }];

                    if (completion) {
                        completion(YES);
                    }

                }];
            }
            else
            {
                if (completion) {
                    completion(NO);
                }
            }
        }];
    }
    else
    {
        NSLog(@"Not Proper Location Object. Only Allow \"VTAnnotation\" or \"CLLocation\" class object");
        if (completion) {
            completion(NO);
        }
    }
}

#pragma mark - Show Route With Google API

-(void) showRouteFromGoogleAPISourceAnnotation:(VTAnnotation *)source destinationAnnotation:(VTAnnotation *)destination attribute:(NSDictionary *) attributes completion:(VTGoogleRouteCompletion)completion
{
    dispatch_async(dispatch_queue_create(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        // Perform Action in Backgroud Thread.
        [self showRouteGoogleAPIFrom:source to:destination attribute:attributes withCompletionBlock:completion];
    });
}

- (void) showRouteFromGoogleAPISourceLocation:(CLLocation *) source destinationLocation:(CLLocation *) destination attribute:(NSDictionary *) attributes completion:(VTGoogleRouteCompletion)completion
{
    dispatch_async(dispatch_queue_create(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        // Perform Action in Backgroud Thread.
        [self showRouteGoogleAPIFrom:source to:destination attribute:attributes withCompletionBlock:completion];
    });
}

-(void) showRouteGoogleAPIFrom:(id)from to:(id)to attribute:(NSDictionary *) attributes withCompletionBlock:(VTGoogleRouteCompletion) completionBlock
{

    if ([self isObjectValidSource:from andDestination:to])
    {
        _routes = [self calculateRoutesFrom:[self get2DCoordinateForObject:from]
                                         to:[self get2DCoordinateForObject:to]];
        NSInteger numberOfSteps = _routes.count;

        //CLLocationCoordinate2D coordinates[numberOfSteps];
        CLLocationCoordinate2D *coordinates = (CLLocationCoordinate2D *) malloc(numberOfSteps * sizeof (CLLocationCoordinate2D));
        for (NSInteger index = 0; index < numberOfSteps; index++)
        {
            CLLocation *location = [_routes objectAtIndex:index];
            CLLocationCoordinate2D coordinate = location.coordinate;
            coordinates[index] = coordinate;
        }



        VTPolyline *polyLine = [VTPolyline polylineWithCoordinates:coordinates count:numberOfSteps];
        polyLine.sourceId = [self getPolylineIdForObject:from];
        polyLine.destinationId = [self getPolylineIdForObject:to];

        if (attributes != nil) {
            polyLine.lineColor = [attributes polyLineColor];
            polyLine.lineWidth = [attributes polyLineWidth];
            polyLine.lineAlpha = [attributes polyLineAlpha];
        }

        dispatch_async(dispatch_get_main_queue(), ^{
            // Perform Action on Main Thread.
            [self addOverlay:polyLine];
            [self centerMap];

            if (completionBlock) {
                completionBlock(YES);
            }

        });
    }
    else
    {
        dispatch_async(dispatch_get_main_queue(), ^{
            // Perform Action on Main Thread.
            NSLog(@"Not Proper Location Object. Only Allow \"VTAnnotation\" or \"CLLocation\" class object");

            if (completionBlock) {
                completionBlock(NO);
            }

        });
    }
}

#pragma mark - Draw Path for Location Array

-(void) showRouteFromAnnotationArray:(NSArray *) annotationArray attribute:(NSDictionary *) attributes completion:(VTDrawPathRouteCompletion)completion
{
    [self showRouteForPath:annotationArray attribute:attributes withCompletion:completion];
}

- (void) showRouteFromCLLocationArray:(NSArray *) locationArray attribute:(NSDictionary *) attributes completion:(VTDrawPathRouteCompletion)completion
{
    [self showRouteForPath:locationArray attribute:attributes withCompletion:completion];
}

- (void) showRouteForPath:(NSArray *) array attribute:(NSDictionary *) attributes withCompletion:(VTDrawPathRouteCompletion)completion
{
    if ([self isArrayHasValidObjects:array])
    {
        NSInteger numberOfSteps = array.count;

        NSInteger finalSteps = 0;
        if (numberOfSteps > 0)
        {
            CLLocationCoordinate2D coordinates[numberOfSteps];
            for (NSInteger index = 0; index < numberOfSteps; index++)
            {
                CLLocationCoordinate2D coordinate = [self get2DCoordinateForObject:[array objectAtIndex:index]];
                coordinates[index] = coordinate;
                finalSteps++;
            }

            if (finalSteps > 0)
            {
                VTPolyline *polyLine = [VTPolyline polylineWithCoordinates:coordinates count:numberOfSteps];
                polyLine.sourceId = [self getPolylineIdForObject:[array objectAtIndex:0]];
                polyLine.destinationId = [self getPolylineIdForObject:[array lastObject]];

                if (attributes != nil) {
                    polyLine.lineColor = [attributes polyLineColor];
                    polyLine.lineWidth = [attributes polyLineWidth];
                    polyLine.lineAlpha = [attributes polyLineAlpha];
                }

                [self addOverlay:polyLine];
            }

            if (completion) {
                completion(YES);
            }
        }
        else
        {
            if (completion) {
                completion(NO);
            }
        }
    }
    else
    {
        if (completion) {
            completion(NO);
        }
    }
}

#pragma mark - Draw Route Utility Methods

-(NSArray*) calculateRoutesFrom:(CLLocationCoordinate2D) f to: (CLLocationCoordinate2D) t
{
    NSString* saddr = [NSString stringWithFormat:@"%f,%f", f.latitude, f.longitude];
    NSString* daddr = [NSString stringWithFormat:@"%f,%f", t.latitude, t.longitude];
    
    NSString* apiUrlStr = [NSString stringWithFormat:@"http://maps.googleapis.com/maps/api/directions/json?origin=%@&destination=%@&sensor=false&mode=driving&alternatives=true", saddr, daddr];
    NSURL* apiUrl = [NSURL URLWithString:apiUrlStr];
    
    NSError* error = nil;
    NSString *apiResponse = [NSString stringWithContentsOfURL:apiUrl encoding:NSASCIIStringEncoding error:&error];
    
    NSDictionary *data = [apiResponse parseJson];
    NSArray *arrRoute = [data valueForKey:@"routes"];
    if (arrRoute.count > 0) {
        NSArray *arrLegs = [[arrRoute objectAtIndex:0]valueForKey:@"legs"];
        if (arrLegs.count > 0) {
            NSArray *arrLocationDict = [[[arrLegs objectAtIndex:0] valueForKey:@"steps"] valueForKeyPath:@"start_location"];
            return [self decodePoint:arrLocationDict];
        }
    }
    return nil;
}

- (NSArray *)decodePoint:(NSArray *)arrLocationDict {
    NSMutableArray *arrLocation = [[NSMutableArray alloc] init];
    for (NSDictionary *dict in arrLocationDict) {
        CLLocation *loc = [[CLLocation alloc] initWithLatitude:[[dict valueForKey:@"lat"] doubleValue] longitude:[[dict valueForKey:@"lng"] doubleValue]];
        [arrLocation addObject:loc];
    }
    return arrLocation;
}

/*
-(NSArray*) calculateRoutesFrom:(CLLocationCoordinate2D) f to: (CLLocationCoordinate2D) t
{
    NSString* saddr = [NSString stringWithFormat:@"%f,%f", f.latitude, f.longitude];
    NSString* daddr = [NSString stringWithFormat:@"%f,%f", t.latitude, t.longitude];

    NSString* apiUrlStr = [NSString stringWithFormat:@"http://maps.google.com/maps?output=dragdir&saddr=%@&daddr=%@", saddr, daddr];
    NSURL* apiUrl = [NSURL URLWithString:apiUrlStr];

    NSError* error = nil;
    NSString *apiResponse = [NSString stringWithContentsOfURL:apiUrl encoding:NSASCIIStringEncoding error:&error];
    NSString *encodedPoints = [apiResponse stringByMatching:@"points:\\\"([^\\\"]*)\\\"" capture:1L];
    return [self decodePolyLine:[encodedPoints mutableCopy]];
}

- (NSMutableArray *)decodePolyLine: (NSMutableString *)encoded
{
    [encoded replaceOccurrencesOfString:@"\\\\" withString:@"\\" options:NSLiteralSearch range:NSMakeRange(0, [encoded length])];
    NSInteger len = [encoded length];
    NSInteger index = 0;
    NSMutableArray *array = [[NSMutableArray alloc] init];
    NSInteger lat=0;
    NSInteger lng=0;
    while (index < len)
    {
        NSInteger b;
        NSInteger shift = 0;
        NSInteger result = 0;
        do
        {
            b = [encoded characterAtIndex:index++] - 63;
            result |= (b & 0x1f) << shift;
            shift += 5;
        } while (b >= 0x20);
        NSInteger dlat = ((result & 1) ? ~(result >> 1) : (result >> 1));
        lat += dlat;
        shift = 0;
        result = 0;
        do
        {
            b = [encoded characterAtIndex:index++] - 63;
            result |= (b & 0x1f) << shift;
            shift += 5;
        } while (b >= 0x20);
        NSInteger dlng = ((result & 1) ? ~(result >> 1) : (result >> 1));
        lng += dlng;
        NSNumber *latitude = [[NSNumber alloc] initWithFloat:lat * 1e-5];
        NSNumber *longitude = [[NSNumber alloc] initWithFloat:lng * 1e-5];

        CLLocation *loc = [[CLLocation alloc] initWithLatitude:[latitude floatValue] longitude:[longitude floatValue]];
        [array addObject:loc];
    }
    return array;
}
*/

-(void) centerMap
{
    MKCoordinateRegion region;
    CLLocationDegrees maxLat = -90.0;
    CLLocationDegrees maxLon = -180.0;
    CLLocationDegrees minLat = 90.0;
    CLLocationDegrees minLon = 180.0;
    for(int idx = 0; idx < _routes.count; idx++)
    {
        CLLocation* currentLocation = [_routes objectAtIndex:idx];
        if(currentLocation.coordinate.latitude > maxLat)
            maxLat = currentLocation.coordinate.latitude;
        if(currentLocation.coordinate.latitude < minLat)
            minLat = currentLocation.coordinate.latitude;
        if(currentLocation.coordinate.longitude > maxLon)
            maxLon = currentLocation.coordinate.longitude;
        if(currentLocation.coordinate.longitude < minLon)
            minLon = currentLocation.coordinate.longitude;
    }
    region.center.latitude     = (maxLat + minLat) / 2.0;
    region.center.longitude    = (maxLon + minLon) / 2.0;
    region.span.latitudeDelta = 0.01;
    region.span.longitudeDelta = 0.01;

    region.span.latitudeDelta  = ((maxLat - minLat)<0.0)?100.0:(maxLat - minLat);
    region.span.longitudeDelta = ((maxLon - minLon)<0.0)?100.0:(maxLon - minLon);
    [self setRegion:region animated:YES];
}

- (BOOL) isObjectValidSource:(id) source andDestination:(id) destination
{
    BOOL isValidObject = NO;
    if ([source isKindOfClass:[VTAnnotation class]] &&
        [destination isKindOfClass:[VTAnnotation class]])
    {
        isValidObject = YES;
    }
    if ([source isKindOfClass:[CLLocation class]] &&
        [destination isKindOfClass:[CLLocation class]])
    {
        isValidObject = YES;
    }
    return isValidObject;
}

- (BOOL) isObjectKindOfVTAnnotation:(id) object
{
    BOOL isVTAnnotation = NO;
    if ([object isKindOfClass:[VTAnnotation class]])
    {
        isVTAnnotation = YES;
    }
    return isVTAnnotation;
}

- (BOOL) isArrayHasValidObjects:(NSArray *) array
{
    BOOL isValidObjects = YES;
    if ([self isArrayKindOfVTAnnotation:array]) {
        for (id object in array) {
            if (![object isKindOfClass:[VTAnnotation class]])
            {
                isValidObjects = NO;
            }
        }
    } else {
        for (id object in array) {
            if (![object isKindOfClass:[CLLocation class]])
            {
                isValidObjects = NO;
            }
        }
    }
    return isValidObjects;
}

- (BOOL) isArrayKindOfVTAnnotation:(NSArray *) array
{
    BOOL isVTAnnotation = YES;
    for (id object in array) {
        if (![object isKindOfClass:[VTAnnotation class]])
        {
            isVTAnnotation = NO;
        }
    }
    return isVTAnnotation;
}


- (CLLocationCoordinate2D) get2DCoordinateForObject:(id) object
{
    CLLocationCoordinate2D coordinate;
    if ([self isObjectKindOfVTAnnotation:object]) {
        coordinate = ((VTAnnotation *) object).coordinate;
    } else {
        coordinate = ((CLLocation *) object).coordinate;
    }
    return coordinate;
}

- (NSString *) getPolylineIdForObject:(id) object
{
    NSString * _id;
    if ([self isObjectKindOfVTAnnotation:object]) {
        _id = ((VTAnnotation *) object).ID;
    } else {
        _id = [NSString stringWithFormat:@"%f#%f",((CLLocation *) object).coordinate.latitude,((CLLocation *) object).coordinate.longitude];
    }
    return _id;
}

- (NSString *) getPolylineIdForAnnotationId:(NSString *) _id
{
    VTAnnotation * annotation = [self getAnnotationForID:_id];
    if (annotation != nil)
    {
        return [self getPolylineIdForObject:annotation];
    }
    return @"";
}


#pragma mark - Object Convertion Methods

- (CLLocation *) clLocationForAnnotation:(VTAnnotation *) annotation
{
    CLLocation *loc = [[CLLocation alloc] initWithLatitude:annotation.coordinate.latitude longitude:annotation.coordinate.longitude];
    return loc;
}

- (CLLocation *) clLocationForCLLocationCoordinate2D:(CLLocationCoordinate2D) coordinate2D
{
    CLLocation *loc = [[CLLocation alloc] initWithLatitude:coordinate2D.latitude longitude:coordinate2D.longitude];
    return loc;
}

#pragma mark - Attribute Dictionary

- (NSDictionary *) getAttribute:(UIColor *)color width:(NSInteger)width alpha:(CGFloat)alpha
{
    NSMutableDictionary * attributes = [[NSMutableDictionary alloc] init];
    [attributes setPolyLineColor:color];
    [attributes setPolyLineWidth:[NSNumber numberWithInteger:width]];
    [attributes setPolyLineAlpha:[NSNumber numberWithFloat:alpha]];

    NSDictionary * returnAttribute = [NSDictionary dictionaryWithDictionary:attributes];
    attributes = nil;

    return returnAttribute;
}

#pragma mark - Map Cumtom Icons

#define CURRENT_LOCATION_IMAGE @"current_location.png"
#define MAP_TYPE_IMAGE @"map_type.png"

#define CURRENT_LOCATION_TAG 2231253
#define MAP_TYPE_TAG 2231254

#define ICON_X_Margin 10
#define ICON_Y_Margin 10

#define ICON_WIDTH 35
#define ICON_HEIGHT 35

- (CGFloat) yMarginForDifferentOS
{
    CGFloat mapYPosition = self.frame.origin.y;
    if (mapYPosition<20) {
        mapYPosition = 20-mapYPosition;
        return mapYPosition;
    }
    return 0.0f;
}

- (CGRect) getFrameForIconTag:(NSInteger) tag
{
    CGRect iconFrame;
    CGFloat yDifference = [self yMarginForDifferentOS];
    if (tag == CURRENT_LOCATION_TAG)
    {
        iconFrame = CGRectMake(ICON_X_Margin, ICON_Y_Margin+yDifference, ICON_WIDTH, ICON_HEIGHT);
    }
    else
    {
        if ([self viewWithTag:CURRENT_LOCATION_TAG]) {
            iconFrame = CGRectMake(ICON_X_Margin, ((ICON_Y_Margin*2)+ICON_HEIGHT+yDifference), ICON_WIDTH, ICON_HEIGHT);
        } else {
            iconFrame = CGRectMake(ICON_X_Margin, ICON_Y_Margin+yDifference, ICON_WIDTH, ICON_HEIGHT);
        }
    }
    return iconFrame;
}

- (void) showCurrentLoctionIcon:(BOOL) isYes
{
    if (isYes)
    {
        if (![self viewWithTag:CURRENT_LOCATION_TAG])
        {
            UIButton * currentLocation = [UIButton buttonWithType:UIButtonTypeCustom];
            [currentLocation setFrame:[self getFrameForIconTag:CURRENT_LOCATION_TAG]];
            [currentLocation setImage:[UIImage imageNamed:CURRENT_LOCATION_IMAGE] forState:UIControlStateNormal];
            [currentLocation setTag:CURRENT_LOCATION_TAG];
            [currentLocation setAutoresizingMask:UIViewAutoresizingFlexibleBottomMargin | UIViewAutoresizingFlexibleRightMargin];
            [currentLocation addTarget:self action:@selector(setCurrentLocation:) forControlEvents:UIControlEventTouchUpInside];
            [self addSubview:currentLocation];
        }
    }
    else
    {
        if ([self viewWithTag:CURRENT_LOCATION_TAG]) {
            [[self viewWithTag:CURRENT_LOCATION_TAG] removeFromSuperview];

            if ([self viewWithTag:MAP_TYPE_TAG])
            {
                [[self viewWithTag:MAP_TYPE_TAG] setFrame:[self getFrameForIconTag:MAP_TYPE_TAG]];
            }
        }
    }
}

- (void) setCurrentLocation:(id) sender
{
    [self setCenterCoordinate:self.userLocation.location.coordinate zoomLevel:[self zoomLevel] animated:YES];
}

- (void) showMapTypeIcon:(BOOL) isYes
{
    if (isYes)
    {
        if (![self viewWithTag:MAP_TYPE_TAG])
        {
            UIButton * mapType = [UIButton buttonWithType:UIButtonTypeCustom];
            [mapType setFrame:[self getFrameForIconTag:MAP_TYPE_TAG]];
            [mapType setImage:[UIImage imageNamed:MAP_TYPE_IMAGE] forState:UIControlStateNormal];
            [mapType setTag:MAP_TYPE_TAG];
            [mapType setAutoresizingMask:UIViewAutoresizingFlexibleBottomMargin | UIViewAutoresizingFlexibleRightMargin];
            [mapType addTarget:self action:@selector(showMapTypeOptions:) forControlEvents:UIControlEventTouchUpInside];
            [self addSubview:mapType];
        }
    }
    else
    {
        if ([self viewWithTag:MAP_TYPE_TAG]) {
            [[self viewWithTag:MAP_TYPE_TAG] removeFromSuperview];
        }
    }
}

- (void) showMapTypeOptions:(id)sender
{
    if ([UIAlertController class])
    {
        UIAlertController * alertController = [UIAlertController alertControllerWithTitle:nil message:nil preferredStyle:UIAlertControllerStyleActionSheet];

        // Cancel Action
        UIAlertAction *cancelAction = [UIAlertAction
                                       actionWithTitle:NSLocalizedString(@"Cancel", @"Cancel action")
                                       style:UIAlertActionStyleCancel
                                       handler:^(UIAlertAction *action)
                                       {
                                           // Cancel action
                                       }];

        // Map Type Hybrid Action
        UIAlertAction *hybridAction = [UIAlertAction
                                       actionWithTitle:NSLocalizedString(@"Hybrid", @"Hybrid action")
                                       style:UIAlertActionStyleDefault
                                       handler:^(UIAlertAction *action)
                                       {
                                           [self setMapType:MKMapTypeHybrid];
                                       }];

        // Map Type Satellite Action
        UIAlertAction *satelliteAction = [UIAlertAction
                                          actionWithTitle:NSLocalizedString(@"Satellite", @"Satellite action")
                                          style:UIAlertActionStyleDefault
                                          handler:^(UIAlertAction *action)
                                          {
                                              [self setMapType:MKMapTypeSatellite];
                                          }];

        // Map Type Standard Action
        UIAlertAction *standardAction = [UIAlertAction
                                         actionWithTitle:NSLocalizedString(@"Standard", @"Standard action")
                                         style:UIAlertActionStyleDefault
                                         handler:^(UIAlertAction *action)
                                         {
                                             [self setMapType:MKMapTypeStandard];
                                         }];

        [alertController addAction:cancelAction];
        [alertController addAction:standardAction];
        [alertController addAction:satelliteAction];
        [alertController addAction:hybridAction];

        if (IS_IPAD()) {
            UIPopoverPresentationController *popover = alertController.popoverPresentationController;
            if (popover)
            {
                popover.sourceView = sender;
                popover.sourceRect = [(UIButton*)sender bounds];
                popover.permittedArrowDirections = UIPopoverArrowDirectionAny;
            }
            NSLog(@"Need To Add Some Code");
        } else {
            [(UIViewController *)_vtMapDelegate presentViewController:alertController animated:YES completion:nil];
        }
    }
    else
    {
        UIActionSheet * actionSheet = [[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:@"Cancel" destructiveButtonTitle:nil otherButtonTitles:@"Standard", @"Satellite", @"Hybrid", nil];
        [actionSheet showInView:((UIViewController*)_vtMapDelegate).view];
    }

}

#pragma mark - Action Sheet Delegate

- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex == 0)
    {
        [self setMapType:MKMapTypeStandard];
    }
    else if (buttonIndex == 1)
    {
        [self setMapType:MKMapTypeSatellite];
    }
    else if (buttonIndex == 2)
    {
        [self setMapType:MKMapTypeHybrid];
    }
}

#pragma mark - CLLocation Manager Updates

- (void) startLocationUpdate
{
    // Set Locaton Manager.
    if (!self.locationManager) {
        self.locationManager = [[CLLocationManager alloc] init];
    }
    self.locationManager.delegate = self;
    
#ifdef __IPHONE_8_0
    
    if(SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"8")) {
        // Use one or the other, not both. Depending on what you put in info.plist
        [self.locationManager requestWhenInUseAuthorization];
        [self.locationManager requestAlwaysAuthorization];
    }
#endif
    self.locationManager.distanceFilter = kCLDistanceFilterNone;
    self.locationManager.desiredAccuracy = kCLLocationAccuracyBest;
    [self.locationManager startUpdatingLocation];
}

- (void) stopLocationUpdate
{
    if (self.locationManager) {
        [self.locationManager stopUpdatingLocation];
    }
}


#pragma mark - Fit All Annotation
- (void)zoomMapViewToFitAnnotationsAnimated:(BOOL)animated {
    MKMapRect zoomRect = MKMapRectNull;
    for (id <MKAnnotation> annotation in self.annotations) {
        MKMapPoint annotationPoint = MKMapPointForCoordinate(annotation.coordinate);
        MKMapRect pointRect = MKMapRectMake(annotationPoint.x, annotationPoint.y, 0, 0);
        if (MKMapRectIsNull(zoomRect)) {
            zoomRect = pointRect;
        } else {
            zoomRect = MKMapRectUnion(zoomRect, pointRect);
        }
    }
    [self setVisibleMapRect:zoomRect edgePadding:UIEdgeInsetsMake(10, 10, 10, 10)  animated:animated];
}



/*- (void)zoomMapViewToFitAnnotationsAnimated:(BOOL)animated
{
    NSArray *annotations = self.annotations;
    NSInteger count = [self.annotations count];
    if ( count == 0) { return; } //bail if no annotations

    //convert NSArray of id <MKAnnotation> into an MKCoordinateRegion that can be used to set the map size
    //can't use NSArray with MKMapPoint because MKMapPoint is not an id
    MKMapPoint points[count]; //C array of MKMapPoint struct
    for( int i=0; i<count; i++ ) //load points C array by converting coordinates to points
    {
        CLLocationCoordinate2D coordinate = [(id <MKAnnotation>)[annotations objectAtIndex:i] coordinate];
        points[i] = MKMapPointForCoordinate(coordinate);
    }
    //create MKMapRect from array of MKMapPoint
    MKMapRect mapRect = [[MKPolygon polygonWithPoints:points count:count] boundingMapRect];
    //convert MKCoordinateRegion from MKMapRect
    MKCoordinateRegion region = MKCoordinateRegionForMapRect(mapRect);

    //add padding so pins aren't scrunched on the edges
    region.span.latitudeDelta  *= ANNOTATION_REGION_PAD_FACTOR;
    region.span.longitudeDelta *= ANNOTATION_REGION_PAD_FACTOR;
    //but padding can't be bigger than the world
    if( region.span.latitudeDelta > MAX_DEGREES_ARC ) { region.span.latitudeDelta  = MAX_DEGREES_ARC; }
    if( region.span.longitudeDelta > MAX_DEGREES_ARC ){ region.span.longitudeDelta = MAX_DEGREES_ARC; }

    //and don't zoom in stupid-close on small samples
    if( region.span.latitudeDelta  < MINIMUM_ZOOM_ARC ) { region.span.latitudeDelta  = MINIMUM_ZOOM_ARC; }
    if( region.span.longitudeDelta < MINIMUM_ZOOM_ARC ) { region.span.longitudeDelta = MINIMUM_ZOOM_ARC; }
    //and if there is a sample of 1 we want the max zoom-in instead of max zoom-out
    if( count == 1 )
    {
        region.span.latitudeDelta = MINIMUM_ZOOM_ARC;
        region.span.longitudeDelta = MINIMUM_ZOOM_ARC;
    }
    [self setRegion:region animated:animated];
}*/

@end
