

#import "VTPolyline.h"

NSString *VTPolyLineColor = @"VTPolyLineColor";
NSString *VTPolyLineWidth = @"VTPolyLineWidth";
NSString *VTPolyLineAlpha = @"VTPolyLineAlpha";

@implementation VTPolyline

- (instancetype) init
{
    if (self = [super init])
    {
        [self setDefaultValue];
    }
    return self;
}

- (void) setDefaultValue
{
    // Set Default Line Property.
    self.lineColor = [UIColor blueColor];
    self.lineWidth = 5;
    self.lineAlpha = 0.5;
}

@end

@implementation NSDictionary (VTPolylineAttributes)

- (UIColor *)polyLineColor {
    return [self objectForKey:VTPolyLineColor];
}

- (NSInteger)polyLineWidth {
    return [[self objectForKey:VTPolyLineWidth] integerValue];
}

- (CGFloat)polyLineAlpha {
    return [[self objectForKey:VTPolyLineAlpha] floatValue];
}

- (void)setPolyLineColor:(UIColor *) color {
    return [self setValue:color forKey:VTPolyLineColor];
}

- (void)setPolyLineWidth:(NSNumber *) width {
    return [self setValue:width forKey:VTPolyLineWidth];
}

- (void)setPolyLineAlpha:(NSNumber *) alpha {
    return [self setValue:alpha forKey:VTPolyLineAlpha];
}

@end
