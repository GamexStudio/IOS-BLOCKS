
#import <MapKit/MapKit.h>

/*!
 *  Custom MKPolyline Class for give a more control.
 */
@interface VTPolyline : MKPolyline

/*!
 *  Set Polyline Id for Source object.
 */
@property (nonatomic, retain) NSString * sourceId;

/*!
 *  Set Polyline Id for Destination object.
 */
@property (nonatomic, retain) NSString * destinationId;

/*!
 *  Set Polyline path color.
 */
@property (nonatomic, retain) UIColor * lineColor;

/*!
 *  Set Polyline path width.
 */
@property (nonatomic, readwrite) NSInteger lineWidth;

/*!
 *  Set Polyline path alpha.
 */
@property (nonatomic, readwrite) CGFloat lineAlpha;

@end


/*!
 *  VTPolyline attribute category for setting and getting properties of VTPolyline Path.
 */
@interface NSDictionary (VTPolylineAttributes)

// get Polyline Property
- (UIColor *)polyLineColor;
- (NSInteger)polyLineWidth;
- (CGFloat)polyLineAlpha;

// Set Polyline Property
- (void)setPolyLineColor:(UIColor *) color;
- (void)setPolyLineWidth:(NSNumber *) width;
- (void)setPolyLineAlpha:(NSNumber *) alpha;

@end
