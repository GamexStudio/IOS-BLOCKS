


#import <MapKit/MapKit.h>

#import "VTAnnotation.h"
#import "VTPolyline.h"

/*!
 *  VTMapView Delegate Methods.
 */
@protocol VTMapViewDelegate <NSObject>

@optional
/*!
 *  Method invoke when annotation did select and set vtMapDelegate to self by reciver class.
 *
 *  @param annotation selected annotation object.
 *  @param aMapView   current map view object.
 */
- (void) didSelectAnnotationView:(VTAnnotation *)annotation forMapView:(id)aMapView;


/*!
 *  Method invoke when annotation did deselect and set vtMapDelegate to self by reciver class.
 *
 *  @param annotation recently deselected annotation object.
 *  @param aMapView   current map view object.
 */
- (void) didDeselectAnnotationView:(VTAnnotation *)annotation forMapView:(id)aMapView;

- (void)calloutAccessoryControlTapped:(UIControl *)control mapView:(MKMapView *)mapView annotationView:(MKAnnotationView *)view;

@end

/*!
 *  VTMapKitAPIRouteCompletion block.
 *
 *  @param isSuccess return BOOL value for notification, is opration success or not.
 */
typedef void (^VTMapKitAPIRouteCompletion) (BOOL isSuccess);

/*!
 *  VTGoogleRouteCompletion block.
 *
 *  @param isSuccess return BOOL value for notification, is opration success or not.
 */
typedef void (^VTGoogleRouteCompletion) (BOOL isSuccess);

/*!
 *  VTDrawPathRouteCompletion block.
 *
 *  @param isSuccess return BOOL value for notification, is opration success or not.
 */
typedef void (^VTDrawPathRouteCompletion) (BOOL isSuccess);

/*!
 *  VTAnnotationLocationChange block.
 *
 *  @param isSuccess return final changed VTAnnotation object.
 */
typedef void (^VTAnnotationLocationChange) (VTAnnotation * annotation);

/*!
 *  VTRemoveOverlayPath block.
 *
 *  @param isSuccess return BOOL value for notification, is opration success or not.
 */
typedef void (^VTRemoveOverlayPath) (BOOL isSuccess);


/*!
 *  @class VTMapView
 *
 *  @brief Custom MKMapView Class. An extenstion to developer for easy completion of map related tasks.
 *
 */
@interface VTMapView : MKMapView <MKMapViewDelegate, CLLocationManagerDelegate, UIActionSheetDelegate>

/*!
 *  The receiver’s delegate object. Although this parameter may be nil, the delegate is used to respond to taps in the action sheet and should usually be provided.
 */
@property (nonatomic, retain) id <VTMapViewDelegate> vtMapDelegate;

/*!
 *  CLLocationManager object for track use's current location.
 */
@property (nonatomic, retain) CLLocationManager * locationManager;

/*!
 *  Boolean flag for change map region according to user's current location. Change region If flag value set to be YES.
 */
@property (nonatomic, readwrite) BOOL trackUserLocation;

- (void)reloadPin;


/*!
 *  Add Annotation to MKMapView.
 *
 *  @param latitude      latitude value of annotation point.
 *  @param longitude     longitude value of annotation point.
 *  @param title         The title of the annotation. Use this show name of annotation. Although this parameter may be nil,.
 *  @param subTitle      The sub title of the annotation. Use this for give extra information about anonnotation. Although this parameter may be nil.
 *  @param defaultImage  The image to use when annotation in default mode. Although this parameter may be nil.
 *  @param selectedImage The image to use when annotation in selected mode. Although this parameter may be nil.
 *  @param _id           The receiver’s delegate object. Although this parameter may be nil, the delegate is used to respond to taps in the action sheet and should usually be provided.
 *  @param canShow       The flage for is allow to show callout view for annotation.
 */
- (VTAnnotation *) addAnnotationForLatitude:(double) latitude longitude:(double)longitude title:(NSString*) title subTitle:(NSString*) subTitle defaultImage:(UIImage *) defaultImage selctedImage:(UIImage *) selectedImage annotationId:(NSString *) _id canShowCallout:(BOOL) canShow;


/*!
 *  Add Annotation to MKMapView.
 *
 *  @param coordinate    The coordinate of annotation. Use this for find out location of annotation on MKMapView.
 *  @param title         The title of the annotation. Use this show name of annotation. Although this parameter may be nil,.
 *  @param subTitle      The sub title of the annotation. Use this for give extra information about anonnotation. Although this parameter may be nil.
 *  @param defaultImage  The image to use when annotation in default mode. Although this parameter may be nil.
 *  @param selectedImage The image to use when annotation in selected mode. Although this parameter may be nil.
 *  @param _id           The receiver’s delegate object. Although this parameter may be nil, the delegate is used to respond to taps in the action sheet and should usually be provided.
 *  @param canShow       The flage for is allow to show callout view for annotation.
 */
- (VTAnnotation *) addAnnotationWithCoordinate:(CLLocationCoordinate2D) coordinate title:(NSString*) title subTitle:(NSString*) subTitle defaultImage:(UIImage *) defaultImage selctedImage:(UIImage *) selectedImage annotationId:(NSString *) _id canShowCallout:(BOOL) canShow;


/*!
 *  Get Unique Id for add next annotation in MKMapView
 *
 *  @return It will return unique annotation that was not added in MapView.
 */
- (NSString *) getUniqueAnnotationId;


/*!
 *  Get Previously Add Annotation Object with Annotation Id.
 *
 *  @param _id The Id of Annotation in NSString object.
 *
 *  @return It's return an VTAnnotation object.
 */
- (VTAnnotation *) getAnnotationForID:(NSString *) _id;


/*!
 *  Get Previously Add Annotation Object with latitude and longitude.
 *
 *  @param latitude  The latitude value as double.
 *  @param longitide The longitide value as double.
 *
 *  @return It's return an VTAnnotation object.
 */
- (VTAnnotation *) getAnnotationForLatitude:(double) latitude longitute:(double) longitide;


/*!
 *  Change Annotation location with animation.
 *
 *  @param location  New location where you want to relocate an annotation.
 *  @param _id       The Annotation Id as NSString object.
 *  @param animation Flag for perform animation while changing annotation location.
 *  @param changed   Completion ^Block (VTAnnotationLocationChange). It will be invoke after location changed.
 */
- (void) changeAnnotationLocation:(CLLocation *)location forAnnotationId:(NSString *)_id animation:(BOOL) animation completion:(VTAnnotationLocationChange)changed;


/*!
 *  Remove All Overlay Path for Map View. But that path must be class of "VTPolyline".
 */
- (void) removeAllPaths;


/*!
 *  Remove Path from Map with Source and Destination Id.
 *
 *  @param sourceId      The source annotation id.
 *  @param destinationId The source destination id.
 */
- (void) removePathForSourceId:(NSString *)sourceId destinationId:(NSString *)destinationId;


/*!
 *  Draw Route between Source and Destination Annotation using MKMapKit Direction API.
 *
 *  @param source      The Source object of VTAnnotation class. It's use as start location of path.
 *  @param destination The Destination object of VTAnnotation class. It's use as end location of path.
 *  @param attributes  The attributes of path. This attribute use "VTPolylineAttributes" category for set properties of path. Although this parameter may be nil.
 *  @param completion  Completion ^Block (VTMapKitAPIRouteCompletion). It will be invoke after draw a path.
 */
- (void) drawPathFromSourceAnnotation:(VTAnnotation *) source destinationAnnotation:(VTAnnotation *) destination attribute:(NSDictionary *) attributes completion:(VTMapKitAPIRouteCompletion)completion;


/*!
 *  Draw Route between Source and Destination Annotation using MKMapKit Direction API.
 *
 *  @param source      The Source object of CLLocation class. It's use as start location of path.
 *  @param destination The Destination object of CLLocation class. It's use as end location of path.
 *  @param attributes  The attributes of path. This attribute use "VTPolylineAttributes" category for set properties of path. Although this parameter may be nil.
 *  @param completion  Completion ^Block (VTMapKitAPIRouteCompletion). It will be invoke after draw a path.
 */
- (void) drawPathFromSourceLocation:(CLLocation *) source destinationLocation:(CLLocation *) destination attribute:(NSDictionary *) attributes completion:(VTMapKitAPIRouteCompletion)completion;


/*!
 *  Draw Route between Source and Destination Annotation using Google Route API.
 *
 *  @param source      The Source object of VTAnnotation class. It's use as start location of path.
 *  @param destination The Destination object of VTAnnotation class. It's use as end location of path.
 *  @param attributes  The attributes of path. This attribute use "VTPolylineAttributes" category for set properties of path. Although this parameter may be nil.
 *  @param completion  Completion ^Block (VTGoogleRouteCompletion). It will be invoke after draw a path.
 */
- (void) showRouteFromGoogleAPISourceAnnotation:(VTAnnotation *) source destinationAnnotation:(VTAnnotation *) destination attribute:(NSDictionary *) attributes completion:(VTGoogleRouteCompletion)completion;


/*!
 *  Draw Route between Source and Destination Annotation using Google Route API.
 *
 *  @param source      The Source object of CLLocation class. It's use as start location of path.
 *  @param destination The Destination object of CLLocation class. It's use as end location of path.
 *  @param attributes  The attributes of path. This attribute use "VTPolylineAttributes" category for set properties of path. Although this parameter may be nil.
 *  @param completion  Completion ^Block (VTGoogleRouteCompletion). It will be invoke after draw a path.
 */
- (void) showRouteFromGoogleAPISourceLocation:(CLLocation *) source destinationLocation:(CLLocation *) destination attribute:(NSDictionary *) attributes completion:(VTGoogleRouteCompletion)completion;


/*!
 *  Draw Route for array of VTAnnotation objects.
 *
 *  @param locationArray The Array of VTAnnotation object. Use for draw path using annotation coordinates.
 *  @param attributes    The attributes of path. This attribute use "VTPolylineAttributes" category for set properties of path. Although this parameter may be nil.
 *  @param completion    Completion ^Block (VTDrawPathRouteCompletion). It will be invoke after draw a path.
 */
- (void) showRouteFromAnnotationArray:(NSArray *) locationArray attribute:(NSDictionary *) attributes completion:(VTDrawPathRouteCompletion)completion;


/*!
 *  Draw Route for array of CLLocation objects.
 *
 *  @param locationArray The Array of CLLocation object. Use for draw path using location coordinates.
 *  @param attributes    The attributes of path. This attribute use "VTPolylineAttributes" category for set properties of path. Although this parameter may be nil.
 *  @param completion    Completion ^Block (VTDrawPathRouteCompletion). It will be invoke after draw a path.
 */
- (void) showRouteFromCLLocationArray:(NSArray *) locationArray attribute:(NSDictionary *) attributes completion:(VTDrawPathRouteCompletion)completion;


/*!
 *  Convert VTAnnotation object into CLLocation object.
 *
 *  @param annotation The VTAnnotation class object.
 *
 *  @return converted object of class CLLocation.
 */
- (CLLocation *) clLocationForAnnotation:(VTAnnotation *) annotation;


/*!
 *  Convert CLLocationCoordinate2D object into CLLocation object.
 *
 *  @param coordinate2D The CLLocationCoordinate2D class object.
 *
 *  @return converted object of class CLLocation.
 */
- (CLLocation *) clLocationForCLLocationCoordinate2D:(CLLocationCoordinate2D) coordinate2D;


/*!
 *  Convert  VTAnnotation or CLLocation class object into CLLocationCoordinate2D class object.
 *
 *  @param object The object type of VTAnnotation or CLLocation class.
 *
 *  @return converted object of class CLLocationCoordinate2D.
 */
- (CLLocationCoordinate2D) get2DCoordinateForObject:(id) object;


/*!
 *  Get Polyline Id from VTAnnotation or CLLocation class object.
 *
 *  @param object The object type of VTAnnotation or CLLocation class.
 *
 *  @return id of polyline path at VTAnnotation or CLLocation location.
 */
- (NSString *) getPolylineIdForObject:(id) object;


/*!
 *  Get Polyline Id from VTAnnotation class object.
 *
 *  @param _id The _id of VTAnnotation object.
 *
 *  @return id of polyline path at VTAnnotation location.
 */
- (NSString *) getPolylineIdForAnnotationId:(NSString *) _id;


/*!
 *  Get Attribute Dictionary for Polyline Path.
 *
 *  @param color The color object of UIColor class. Use for set color of polyline path.
 *  @param width The width object of NSInteger class. Use for set width of polyline path.
 *  @param alpha The alpha object of CGFlote class. Use for set width of polyline path. Although this parameter value must between 0 to 1.
 *
 *  @return NSDictionary with polyline attributes.
 */
- (NSDictionary *) getAttribute:(UIColor *)color width:(NSInteger)width alpha:(CGFloat)alpha;


/*!
 *  Show icon for animate map to user's current location.
 *
 *  @param isYes The isYes flag. Use for show and hide current location icon on map. Icon will display when isYes flag value YES.
 */
- (void) showCurrentLoctionIcon:(BOOL) isYes;


/*!
 *  Show icon for change map type.
 *
 *  @param isYes isYes The isYes flag. Use for show and hide map type icon on map. Icon will display when isYes flag value YES.
 */
- (void) showMapTypeIcon:(BOOL) isYes;


- (void)zoomMapViewToFitAnnotationsAnimated:(BOOL)animated;

@end
