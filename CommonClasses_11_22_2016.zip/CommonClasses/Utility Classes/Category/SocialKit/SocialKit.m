//
//  SocialKit.m
//  
//
//  
//
//

#import "SocialKit.h"
#import "CommonVaribles.h"
#import "UIAlertView+Blocks.h"

@implementation SocialKit


#pragma mark - Twitter
+ (void)twitterLoginWithCompletion:(completionBlock)completionHandler {
    ACAccountStore *store = [[ACAccountStore alloc] init];
    ACAccountType *twitterType = [store accountTypeWithAccountTypeIdentifier:ACAccountTypeIdentifierTwitter];
    [store requestAccessToAccountsWithType:twitterType options:nil completion:^(BOOL granted, NSError *error) {
        if(granted) {
            NSArray *twitterAccounts = [store accountsWithAccountType:twitterType];
            if(twitterAccounts == nil || [twitterAccounts count] == 0) {
                [UIAlertView showWithTitle:@"No Twitter Accounts" message:@"There are no Twitter accounts configured. You can add or create a Twitter account in Settings." cancelButtonTitle:@"Cancel" otherButtonTitles:[NSArray arrayWithObject:@"Settings"] tapBlock:^(UIAlertView *alertView, NSInteger buttonIndex) {
                    if (buttonIndex == 1) {
                        if (CAN_OPEN_URL(UIApplicationOpenSettingsURLString)) {
                            OPEN_URL(UIApplicationOpenSettingsURLString);
                        }
                    }
                }];
            } else {
                [self getUserDetailFromTwitterAccount:[twitterAccounts objectAtIndex:0] WithCompletion:^(NSDictionary *info, NSError *error) {
                    completionHandler(info,error);
                }];
            }
        }else{
            [UIAlertView showWithMessage:@"Twitter Permission not grated" cancelButtonTitle:@"Ok"];
            dispatch_async(dispatch_get_main_queue(), ^{
                completionHandler(nil,error);
            });
        }
    }];
}

+(void)getUserDetailFromTwitterAccount:(ACAccount*)twitterAccount WithCompletion:(void (^)(NSDictionary  *info, NSError *error))completionHandler {
    
    NSURL *requestURL = [NSURL URLWithString:@"https://api.twitter.com/1.1/users/show.json"];
    
    SLRequest *request = [SLRequest requestForServiceType:SLServiceTypeTwitter
                                            requestMethod:SLRequestMethodGET
                                                      URL:requestURL
                                               parameters:[NSDictionary dictionaryWithObject:twitterAccount.username forKey:@"screen_name"]];
    request.account = twitterAccount;
    
    [request performRequestWithHandler:^(NSData *data,
                                         NSHTTPURLResponse *response,
                                         NSError *error)
     {
         NSMutableDictionary *list = [[NSMutableDictionary alloc]init];
         if(!error) {
             list =[NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:&error];
             NSDictionary *info = @{@"TwitterID":[list valueForKey:@"id"],@"Name":[list valueForKey:@"name"],@"ProfileImageURL":[list valueForKey:@"profile_image_url_https"]};
             dispatch_async(dispatch_get_main_queue(), ^{
                 completionHandler(info,nil);
             });
             
         }else {
             [UIAlertView showWithMessage:error.description cancelButtonTitle:@"Ok"];
             dispatch_async(dispatch_get_main_queue(), ^{
                 completionHandler(nil,error);
             });
         }
     }];
}


#pragma mark - Facebook

+ (void)facebookLoginWithKey:(NSString *)facebookKey completion:(completionBlock)completionHandler {
    fbAccountStore = [[ACAccountStore alloc]init];
    ACAccountType *FBaccountType = [fbAccountStore accountTypeWithAccountTypeIdentifier:ACAccountTypeIdentifierFacebook];;
    
    NSDictionary *dictFB = [NSDictionary dictionaryWithObjectsAndKeys:facebookKey,ACFacebookAppIdKey,@[@"email"],ACFacebookPermissionsKey, nil];
    
    [fbAccountStore requestAccessToAccountsWithType:FBaccountType options:dictFB completion:
     ^(BOOL granted, NSError *e) {
         if (granted) {
             NSArray *accounts = [fbAccountStore accountsWithAccountType:FBaccountType];
             [self getUserDetailFromFacebookAccount:[accounts lastObject] Completion:^(NSDictionary *info, NSError *error) {
                 completionHandler(info,error);
             }];
         }
         else {
             dispatch_async(dispatch_get_main_queue(), ^{
                                NSLog(@"%@",e.description);
                 NSError *error = e;
                                if([e code]== ACErrorAccountNotFound) {
                                    [UIAlertView showWithTitle:@"" message:@"Please setup your Facebook account in Settings App." cancelButtonTitle:@"Cancel" otherButtonTitles:@[@"Settings"] tapBlock:^(UIAlertView *alertView, NSInteger buttonIndex) {
                                        if (buttonIndex == 1) {
                                            if (CAN_OPEN_URL(UIApplicationOpenSettingsURLString)) {
                                                OPEN_URL(UIApplicationOpenSettingsURLString);
                                            }
                                        }
                                    }];
                                } else {
                                    [UIAlertView showWithMessage:@"Access Denied" cancelButtonTitle:@"Ok"];
                                    error = [NSError errorWithDomain:@"Facebook" code:1 userInfo:@{@"Access Denied":NSLocalizedDescriptionKey}];
                                }
                                completionHandler(nil,error);
                            });
             NSLog(@"error getting permission %@",e);
         }
     }];
}

+ (void)getUserDetailFromFacebookAccount:(ACAccount *)facebookAccount  Completion:(void (^)(NSDictionary  *info, NSError *error))completionHandler {
    /**
    * Facebook Parameter Referernce Link
    * https://developers.facebook.com/docs/graph-api/reference/user
    */
    
    NSDictionary *dictParameters = @{@"fields":@"id,first_name,last_name,email"};
    NSURL *requestURL = [NSURL URLWithString:@"https://graph.facebook.com/me"];
    SLRequest *request = [SLRequest requestForServiceType:SLServiceTypeFacebook
                                            requestMethod:SLRequestMethodGET
                                                      URL:requestURL
                                               parameters:dictParameters];
    request.account = facebookAccount;
    
    [request performRequestWithHandler:^(NSData *data,
                                         NSHTTPURLResponse *response,
                                         NSError *error) {
         NSMutableDictionary *list = [[NSMutableDictionary alloc]init];
         if(!error) {
             list =[NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:&error];
             if([list objectForKey:@"error"] != nil) {
                 [self attemptRenewCredentialsWithAccount:facebookAccount Completion:completionHandler];
             }else{
                 //call completion block
                 dispatch_async(dispatch_get_main_queue(), ^{
                     completionHandler(list,error);
                 });
             }
         }
        
     }];
}

+ (void)attemptRenewCredentialsWithAccount:(ACAccount *)facebookAccount Completion:(void (^)(NSDictionary  *info, NSError *error))completionHandler{
    [fbAccountStore renewCredentialsForAccount:facebookAccount completion:^(ACAccountCredentialRenewResult renewResult, NSError *error){
        if(!error) {
            switch (renewResult) {
                case ACAccountCredentialRenewResultRenewed: {
                    NSLog(@"Good to go");
                    
                    [self getUserDetailFromFacebookAccount:facebookAccount Completion:^(NSDictionary *info, NSError *error) {                       
                        dispatch_async(dispatch_get_main_queue(), ^{
                            completionHandler(info,error);
                        });
                    }];
                    break;
                }
                case ACAccountCredentialRenewResultRejected: {
                    NSLog(@"User declined permission");
                    [UIAlertView showWithTitle:@"Access Denied" Message:@"You declined permission" cancelButtonTitle:@"Ok"];
                    
                    break;
                }
                case ACAccountCredentialRenewResultFailed: {
                    NSLog(@"non-user-initiated cancel, you may attempt to retry");
                    [UIAlertView showWithTitle:@"" Message:@"Access Denied" cancelButtonTitle:@"Ok"];
                    break;
                }
                default:
                    break;
            }
        }
        else{
            //handle error gracefully
            NSLog(@"error from renew credentials%@",error);
        }
    }];
}

@end
