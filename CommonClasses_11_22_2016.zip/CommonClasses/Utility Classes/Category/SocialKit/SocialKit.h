//
//  SocialKit.h
//  
//
//  
//
//

#import <Foundation/Foundation.h>
#import <Accounts/Accounts.h>
#import <Social/Social.h>

typedef void (^completionBlock)(NSDictionary  *info, NSError *error);

static ACAccountStore *fbAccountStore;

@interface SocialKit : NSObject

+ (void)facebookLoginWithKey:(NSString *)facebookKey completion:(completionBlock)completionHandler;
+ (void)twitterLoginWithCompletion:(completionBlock)completionHandler;

@end
