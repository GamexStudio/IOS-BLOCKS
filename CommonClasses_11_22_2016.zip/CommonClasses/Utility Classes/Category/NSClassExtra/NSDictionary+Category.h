
#import <Foundation/Foundation.h>
#import <CoreGraphics/CoreGraphics.h>

@interface NSDictionary (Category)
- (id)valueOrNilForKey:(NSString *)key;
- (id)valueOrNilForKeyPath:(NSString *)keyPath;

- (long long)longForKey:(NSString *)key;
- (NSInteger)intForKey:(NSString *)key;
- (BOOL)boolForKey:(NSString *)key;
- (CGFloat)floatForKey:(NSString *)key;
- (double)doubleForKey:(NSString *)key;
- (NSString *)stringForKey:(NSString *)key;
- (NSString *)stringForKey:(NSString *)key defaultString:(NSString *)defaultString;

- (CGPoint)pointForKey:(NSString *)key;
- (CGSize)sizeForKey:(NSString *)key;
- (CGRect)rectForKey:(NSString *)key;

- (NSArray *)arrayForKey:(NSString *)key;
- (NSDictionary *)dictionaryForKey:(NSString *)key;

- (BOOL)containsObjectForKey:(id)key;

- (NSString *)URLQueryString;

- (NSString *)XMLString;

- (NSString*) jsonString;
- (id) objectForCaseInsensitiveKey:(id)aKey;

+ (NSDictionary *) dictionaryWithPropertiesOfObject:(id)obj;
+ (NSDictionary *) dictionaryWithPropertiesOfObject:(id)obj withSubClassType:(NSArray *)arrSubclassType;


- (NSDictionary *)dictionaryByMergingWith:(NSDictionary *)dict;
+ (NSDictionary *)dictionaryByMerging:(NSDictionary *)dict1 with:(NSDictionary *)dict2;
@end

@interface NSDictionary (DeepMutableCopy)

- (NSMutableDictionary *)deepMutableCopy;

@end

@interface NSMutableDictionary (bbCategory)

- (void)setInt:(NSInteger)value forKey:(NSString *)key;
- (void)setBool:(BOOL)value forKey:(NSString *)key;
- (void)setFloat:(CGFloat)value forKey:(NSString *)key;
- (void)setDouble:(double)value forKey:(NSString *)key;
- (void)setString:(NSString *)value forKey:(NSString *)key;

- (void)setPoint:(CGPoint)value forKey:(NSString *)key;
- (void)setSize:(CGSize)value forKey:(NSString *)key;
- (void)setRect:(CGRect)value forKey:(NSString *)key;

-(void) setObject:(id) obj forCaseInsensitiveKey:(id)aKey;
@end
