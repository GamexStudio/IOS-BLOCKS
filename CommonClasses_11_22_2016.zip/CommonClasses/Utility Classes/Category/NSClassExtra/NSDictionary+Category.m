#import "NSDictionary+Category.h"

#import "NSObject+Category.h"
#import "CommonHeaders.h"

@implementation NSDictionary (Category)

- (id)valueOrNilForKey:(NSString *)key {
    id object = [self valueForKey:key];
    if ([object isEqual:[NSNull null]]) {
        return nil;
    }
    return object;
}

- (id)valueOrNilForKeyPath:(NSString *)keyPath {
    id object = [self valueForKeyPath:keyPath];
    if ([object isEqual:[NSNull null]]) {
        return nil;
    }
    return object;
}

- (long long)longForKey:(NSString *)key
{
    long long value = 0;
    
    id object = [self objectForKey:key];
    if ([object isValidObject] && ([object isKindOfClass:[NSValue class]] || [object isKindOfClass:[NSString class]]))
    {
        value = [object longLongValue];
    }
    
    return value;
}

- (NSInteger)intForKey:(NSString *)key
{
    NSInteger value = 0;
    
    id object = [self objectForKey:key];
    if ([object isValidObject] && ([object isKindOfClass:[NSValue class]] || [object isKindOfClass:[NSString class]]))
    {
        value = [object integerValue];
    }
    
    return value;
}

- (BOOL)boolForKey:(NSString *)key
{
    BOOL value = NO;
    
    id object = [self objectForKey:key];
    if ([object isValidObject] && ([object isKindOfClass:[NSValue class]] || [object isKindOfClass:[NSString class]]))
    {
        value = [object boolValue];
    }
    
    return value;
}

- (CGFloat)floatForKey:(NSString *)key
{
    float value = 0.0f;
    
    id object = [self objectForKey:key];
    if ([object isValidObject] && ([object isKindOfClass:[NSValue class]] || [object isKindOfClass:[NSString class]]))
    {
        value = [object floatValue];
    }
    
    return value;
}

- (double)doubleForKey:(NSString *)key
{
    double value = 0.0f;
    
    id object = [self objectForKey:key];
    if ([object isValidObject] && ([object isKindOfClass:[NSValue class]] || [object isKindOfClass:[NSString class]]))
    {
        value = [object doubleValue];
    }
    
    return value;
}

- (NSString *)stringForKey:(NSString *)key
{
    NSString *value = nil;
    
    id object = [self objectForKey:key];
    if ([object isValidObject] && [object isKindOfClass:[NSString class]])
    {
        value = object;
    }
    else if([object isValidObject] && [object isKindOfClass:[NSNumber class]])
    {
        value = [object stringValue];
    }
    
    return value;
}

- (NSString *)stringForKey:(NSString *)key defaultString:(NSString *)defaultString
{
    NSString *value = [self stringForKey:key];
    
    if (!value)
    {
        return defaultString;
    }

    return value;
}

- (CGPoint)pointForKey:(NSString *)key
{
  CGPoint point = CGPointZero;
  NSDictionary *dictionary = [self valueForKey:key];
    
    if ([dictionary isValidObject] && [dictionary isKindOfClass:[NSDictionary class]])
    {
        BOOL success = CGPointMakeWithDictionaryRepresentation((__bridge CFDictionaryRef)dictionary, &point);
        if (success)
            return point;
        else
            return CGPointZero;
    }
    
   return CGPointZero;
}

- (CGSize)sizeForKey:(NSString *)key
{
  CGSize size = CGSizeZero;
  NSDictionary *dictionary = [self valueForKey:key];
    
    if ([dictionary isValidObject] && [dictionary isKindOfClass:[NSDictionary class]])
    {
        BOOL success = CGSizeMakeWithDictionaryRepresentation((__bridge CFDictionaryRef)dictionary, &size);
        if (success)
            return size;
        else
            return CGSizeZero;
    }
    
    return CGSizeZero;
}

- (CGRect)rectForKey:(NSString *)key
{
  CGRect rect = CGRectZero;
  NSDictionary *dictionary = [self valueForKey:key];
    
    if ([dictionary isValidObject] && [dictionary isKindOfClass:[NSDictionary class]])
    {
        BOOL success = CGRectMakeWithDictionaryRepresentation((__bridge CFDictionaryRef)dictionary, &rect);
        if (success)
            return rect;
        else
            return CGRectZero;
    }
    
    return CGRectZero;
}

- (NSArray *)arrayForKey:(NSString *)key
{
    NSArray *value = nil;
    
    id object = [self objectForKey:key];
    if ([object isValidObject] && [object isKindOfClass:[NSArray class]])
    {
        value = object;
    }
    
    return value;
}

- (NSDictionary *)dictionaryForKey:(NSString *)key
{
    NSDictionary *value = nil;
    
    id object = [self objectForKey:key];
    if ([object isValidObject] && [object isKindOfClass:[NSDictionary class]])
    {
        value = object;
    }
    
    return value;
}

- (BOOL)containsObjectForKey:(id)key
{
    return [[self allKeys] containsObject:key];
}

-(id) objectForCaseInsensitiveKey:(id)aKey {
    for (NSString *key in self.allKeys) {
        if ([key compare:aKey options:NSCaseInsensitiveSearch] == NSOrderedSame) {
            return [self objectForKey:key];
        }
    }
    return  nil;
}


- (NSString *)URLQueryString
{
    NSMutableString *string = [NSMutableString string];
    for (NSString *key in [self allKeys]) {
        if ([string length]) {
            [string appendString:@"&"];
        }
        CFStringRef escaped = CFURLCreateStringByAddingPercentEscapes(NULL,(CFStringRef)[[self objectForKey:key] description],
                                                                      NULL,(CFStringRef)@"!*'();:@&=+$,/?%#[]",
                                                                      kCFStringEncodingUTF8);
        [string appendFormat:@"%@=%@", key, escaped];
        CFRelease(escaped);
    }
    return string;
}

- (NSString *)XMLString {
    
    NSString *xmlStr = @"<xml>";
    
    for (NSString *key in self.allKeys) {
        
        NSString *value = [self objectForKey:key];
        
        xmlStr = [xmlStr stringByAppendingString:[NSString stringWithFormat:@"<%@>%@</%@>", key, value, key]];
    }
    
    xmlStr = [xmlStr stringByAppendingString:@"</xml>"];
    
    return xmlStr;
}


#pragma mark - Json Representation
-(NSString*) jsonString {
    NSError *error;
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:self
                                                       options:(NSJSONWritingOptions)0
                                                         error:&error];
    
    if (! jsonData) {
        NSLog(@"bv_jsonStringWithPrettyPrint: error: %@", error.localizedDescription);
        return @"{}";
    } else {
        return [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    }
}


// Create Dictionary from Custom NSObject Class
+ (NSDictionary *) dictionaryWithPropertiesOfObject:(id)obj
{
    NSMutableDictionary *dict = [NSMutableDictionary dictionary];
    
    unsigned count;
    objc_property_t *properties = class_copyPropertyList([obj class], &count);
    
    for (int i = 0; i < count; i++) {
        NSString *key = [NSString stringWithUTF8String:property_getName(properties[i])];
        NSLog(@"%@",NSStringFromClass([[obj valueForKey:key] class]));
        [dict setObject:[obj valueForKey:key]?[obj valueForKey:key]:@"" forKey:key];
    }
    
    free(properties);
    
    return [NSDictionary dictionaryWithDictionary:dict];
}

+ (NSDictionary *) dictionaryWithPropertiesOfObject:(id)obj withSubClassType:(NSArray *)arrSubclassType
{
    static NSMutableDictionary *dict;
    dict = [NSMutableDictionary dictionary];
    
    unsigned count;
    objc_property_t *properties = class_copyPropertyList([obj class], &count);
    
    for (int i = 0; i < count; i++) {
        NSString *key = [NSString stringWithUTF8String:property_getName(properties[i])];
        if ([arrSubclassType containsObject:NSStringFromClass([[obj valueForKey:key] class])]) {
            [dict setObject:[NSDictionary dictionaryWithPropertiesOfObject:[obj valueForKey:key]] forKey:key];
        }else{
            [dict setObject:[obj valueForKey:key]?[obj valueForKey:key]:@"" forKey:key];
        }
    }
    
    free(properties);
    
    return [NSDictionary dictionaryWithDictionary:dict];
}


#pragma mark - Merge
+ (NSDictionary *)dictionaryByMerging:(NSDictionary *)dict1 with:(NSDictionary *)dict2 {
    NSMutableDictionary * result = [NSMutableDictionary dictionaryWithDictionary:dict1];
    NSMutableDictionary * resultTemp = [NSMutableDictionary dictionaryWithDictionary:dict1];
    [resultTemp addEntriesFromDictionary:dict2];
    [resultTemp enumerateKeysAndObjectsUsingBlock: ^(id key, id obj, BOOL *stop) {
        if ([dict1 objectForKey:key]) {
            if ([obj isKindOfClass:[NSDictionary class]]) {
                NSDictionary * newVal = [[dict1 objectForKey: key] dictionaryByMergingWith: (NSDictionary *) obj];
                [result setObject: newVal forKey: key];
            } else {
                [result setObject: obj forKey: key];
            }
        }
        else if([dict2 objectForKey:key])
        {
            if ([obj isKindOfClass:[NSDictionary class]]) {
                NSDictionary * newVal = [[dict2 objectForKey: key] dictionaryByMergingWith: (NSDictionary *) obj];
                [result setObject: newVal forKey: key];
            } else {
                [result setObject: obj forKey: key];
            }
        }
    }];
    return (NSDictionary *) [result mutableCopy];
    
}

- (NSDictionary *)dictionaryByMergingWith:(NSDictionary *)dict {
    return [[self class] dictionaryByMerging:self with: dict];
}


@end


@implementation NSDictionary (DeepMutableCopy)


- (NSMutableDictionary *)deepMutableCopy;
{
    NSMutableDictionary *newDictionary;
    NSEnumerator *keyEnumerator;
    id anObject;
    id aKey;
	
    newDictionary = [self mutableCopy];
    // Run through the new dictionary and replace any objects that respond to -deepMutableCopy or -mutableCopy with copies.
    keyEnumerator = [[newDictionary allKeys] objectEnumerator];
    while ((aKey = [keyEnumerator nextObject])) {
        anObject = [newDictionary objectForKey:aKey];
        if ([anObject respondsToSelector:@selector(deepMutableCopy)]) {
            anObject = [anObject deepMutableCopy];
            [newDictionary setObject:anObject forKey:aKey];
        } else if ([anObject respondsToSelector:@selector(mutableCopyWithZone:)]) {
            anObject = [anObject mutableCopyWithZone:nil];
            [newDictionary setObject:anObject forKey:aKey];
        } else {
			[newDictionary setObject:anObject forKey:aKey];
		}
    }
	
    return newDictionary;
}

@end


@implementation NSMutableDictionary (bbCategory)

- (void)setInt:(NSInteger)value forKey:(NSString *)key
{
    NSNumber *number = [NSNumber numberWithInteger:value];
    [self setObject:number forKey:key];    
}

- (void)setBool:(BOOL)value forKey:(NSString *)key
{
    NSNumber *number = [NSNumber numberWithBool:value];
    [self setObject:number forKey:key];    
}

- (void)setFloat:(CGFloat)value forKey:(NSString *)key
{
    NSNumber *number = [NSNumber numberWithFloat:value];
    [self setObject:number forKey:key];
}

- (void)setDouble:(double)value forKey:(NSString *)key
{
    NSNumber *number = [NSNumber numberWithDouble:value];
    [self setObject:number forKey:key];
}

- (void)setString:(NSString *)value forKey:(NSString *)key
{
    [self setObject:value forKey:key];
}

- (void)setPoint:(CGPoint)value forKey:(NSString *)key
{
    CFDictionaryRef dictionary = CGPointCreateDictionaryRepresentation(value);
    NSDictionary *pointDict = [NSDictionary dictionaryWithDictionary:
                               (__bridge NSDictionary *)dictionary]; // autoreleased
    CFRelease(dictionary);
    
    [self setValue:pointDict forKey:key];
}

- (void)setSize:(CGSize)value forKey:(NSString *)key
{
    CFDictionaryRef dictionary = CGSizeCreateDictionaryRepresentation(value);
    NSDictionary *sizeDict = [NSDictionary dictionaryWithDictionary:
                               (__bridge NSDictionary *)dictionary]; // autoreleased
    CFRelease(dictionary);
    
    [self setValue:sizeDict forKey:key];
}

- (void)setRect:(CGRect)value forKey:(NSString *)key
{
    CFDictionaryRef dictionary = CGRectCreateDictionaryRepresentation(value);
    NSDictionary *rectDict = [NSDictionary dictionaryWithDictionary:
                              (__bridge NSDictionary *)dictionary]; // autoreleased
    CFRelease(dictionary);
    
    [self setValue:rectDict forKey:key];
}

-(void) setObject:(id) obj forCaseInsensitiveKey:(id)aKey {
    for (NSString *key in self.allKeys) {
        if ([key compare:aKey options:NSCaseInsensitiveSearch] == NSOrderedSame) {
            [self setObject:obj forKey:key];
            return;
        }
    }
    [self setObject:obj forKey:aKey];
}

@end
