//
//  NSString+extras.h
//
//  Created on 18/08/11.
//  Copyright 2011. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface NSMutableArray (extras)

- (void)moveObjectToTop:(NSUInteger)index;

- (void)moveObjectFromIndex:(NSUInteger)oldIndex toIndex:(NSUInteger)newIndex;

- (NSMutableArray *)removeFirstObject;


-(void)shuffleArray;

-(void)reverseArray;

@end
