//
//  NSString+extras.m
//
//  Created on 18/08/11.
//  Copyright 2011. All rights reserved.
//

#import "NSMutableArray+extras.h"

@implementation NSMutableArray (extras)

- (void)moveObjectToTop:(NSUInteger)index {
    [self moveObjectFromIndex:index toIndex:0];
}

- (NSMutableArray *)removeFirstObject {
    if([self count]) {
        [self removeObjectAtIndex:0];
    }
    return self;
}

- (void)moveObjectFromIndex:(NSUInteger)origIndex toIndex:(NSUInteger)newIndex {
    if (newIndex != origIndex) {
        id object = [self objectAtIndex:origIndex];
        [self removeObjectAtIndex:origIndex];
        if (newIndex >= [self count]) {
            [self addObject:object];
        } else {
            [self insertObject:object atIndex:newIndex];
        }
    }
}

-(void)shuffleArray {
    for (long i = ([self count]-1); i >= 1; --i) {
        int j = arc4random() % i;
        id tempObject = [self objectAtIndex:j];
        [self replaceObjectAtIndex:j withObject: [self objectAtIndex:i]];
        [self replaceObjectAtIndex:i withObject:tempObject];
    }	
}

-(void)reverseArray {
    long count = [self count];
    for (long i = 0; i < count / 2; ++i) {
        long j = count - i - 1;
        id tempObject = [self objectAtIndex:i];
        [self replaceObjectAtIndex:i withObject:[self objectAtIndex:j]];
        [self replaceObjectAtIndex:j withObject:tempObject];
    }
}

@end
