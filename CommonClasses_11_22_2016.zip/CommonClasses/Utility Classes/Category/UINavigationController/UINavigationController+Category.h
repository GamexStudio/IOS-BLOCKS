
#import <UIKit/UIKit.h>

@interface UINavigationController (Category)

- (id)popToViewControllerWithClassname:(NSString *)className Animated:(BOOL)animated;
- (void)popOrPushToViewController:(UIViewController *)controller Animated:(BOOL)animated;

@end
