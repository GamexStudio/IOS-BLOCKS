

#import "UIView+SubView.h"

@implementation UIView (SubView)

- (void)addSubview:(UIView *)view animationDirection:(AnimationDirection)animationDirection duration:(NSTimeInterval)duration completion:(void (^)(void))completion{
    [self addSubview:view];

    CGPoint newCenter = CGPointMake((view.frame.size.width/2)+view.frame.origin.x, (view.frame.size.height/2)+view.frame.origin.y);

    switch (animationDirection) {
        case kAnimateFromTop:
            view.center = CGPointMake(view.frame.size.width/2, -1*(view.frame.size.height/2));
            break;


        case kAnimateFromBottom:
            view.center = CGPointMake(view.frame.size.width/2, view.frame.size.height*2);
            break;


        case kAnimateFromRight:
            view.center = CGPointMake(view.frame.size.width*2, view.frame.size.height/2);
            break;


        case kAnimateFromLeft:
            view.center = CGPointMake(-1*(view.frame.size.width/2), view.frame.size.height/2);
            break;


        default:
            view.center = CGPointMake(view.frame.size.width/2, -1*(view.frame.size.height/2));
            break;
    }

    [UIView animateWithDuration:duration animations:^{
        view.center = newCenter;
    } completion:^(BOOL finished) {
        if(completion)
            completion();
    }];
}

- (void)addSubview:(UIView *)view  animations:(void (^)(void))animations animationDirection:(AnimationDirection)animationDirection duration:(NSTimeInterval)duration completion:(void (^)(void))completion{
    [self addSubview:view];

    CGPoint newCenter = CGPointMake((view.frame.size.width/2)+view.frame.origin.x, (view.frame.size.height/2)+view.frame.origin.y);

    switch (animationDirection) {
        case kAnimateFromTop:
            view.center = CGPointMake(view.frame.size.width/2, -1*(view.frame.size.height/2));
            break;


        case kAnimateFromBottom:
            view.center = CGPointMake(view.frame.size.width/2, view.frame.size.height*2);
            break;


        case kAnimateFromRight:
            view.center = CGPointMake(view.frame.size.width*2, view.frame.size.height/2);
            break;


        case kAnimateFromLeft:
            view.center = CGPointMake(-1*(view.frame.size.width/2), view.frame.size.height/2);
            break;


        default:
            view.center = CGPointMake(view.frame.size.width/2, -1*(view.frame.size.height/2));
            break;
    }

    [UIView animateWithDuration:duration animations:^{
        if(animations)
            animations();
        view.center = newCenter;
    } completion:^(BOOL finished) {
        if(completion)
            completion();
    }];
}


- (void)addSubview:(UIView *)view frame:(CGRect)frame animationDirection:(AnimationDirection)animationDirection duration:(NSTimeInterval)duration completion:(void (^)(void))completion{
    [view setFrame:frame];
    [self addSubview:view];

    CGPoint newCenter = CGPointMake(view.frame.size.width/2, view.frame.size.height/2);

    switch (animationDirection) {
        case kAnimateFromTop:
            view.center = CGPointMake(view.frame.size.width/2, -1*(view.frame.size.height/2));
            break;


        case kAnimateFromBottom:
            view.center = CGPointMake(view.frame.size.width/2, view.frame.size.height*2);
            break;


        case kAnimateFromRight:
            view.center = CGPointMake(view.frame.size.width*2, view.frame.size.height/2);
            break;


        case kAnimateFromLeft:
            view.center = CGPointMake(-1*(view.frame.size.width/2), view.frame.size.height/2);
            break;


        default:
            view.center = CGPointMake(view.frame.size.width/2, -1*(view.frame.size.height/2));
            break;
    }

    [UIView animateWithDuration:duration animations:^{
        view.center = newCenter;
    } completion:^(BOOL finished) {
        if(completion)
            completion();
    }];
}

- (void)insertSubview:(UIView *)view atIndex:(NSInteger)index animationDirection:(AnimationDirection)animationDirection duration:(NSTimeInterval)duration completion:(void (^)(void))completion{
    [self insertSubview:view atIndex:index];

    CGPoint newCenter = CGPointMake((view.frame.size.width/2)+view.frame.origin.x, (view.frame.size.height/2)+view.frame.origin.y);

    switch (animationDirection) {
        case kAnimateFromTop:
            view.center = CGPointMake(view.frame.size.width/2, -1*(view.frame.size.height/2));
            break;


        case kAnimateFromBottom:
            view.center = CGPointMake(view.frame.size.width/2, view.frame.size.height*2);
            break;


        case kAnimateFromRight:
            view.center = CGPointMake(view.frame.size.width*2, view.frame.size.height/2);
            break;


        case kAnimateFromLeft:
            view.center = CGPointMake(-1*(view.frame.size.width/2), view.frame.size.height/2);
            break;


        default:
            view.center = CGPointMake(view.frame.size.width/2, -1*(view.frame.size.height/2));
            break;
    }

    [UIView animateWithDuration:duration animations:^{
        view.center = newCenter;
    } completion:^(BOOL finished) {
        if(completion)
            completion();
    }];
}

- (void)removeFromSuperview:(AnimationDirection)animationDirection duration:(NSTimeInterval)duration completion:(void (^)(void))completion{
    CGPoint newCenter;
    switch (animationDirection) {
        case kAnimateFromTop:
            newCenter = CGPointMake(self.superview.frame.size.width/2, -1*(self.superview.frame.size.height));
            break;

        case kAnimateFromBottom:
            newCenter = CGPointMake(self.superview.frame.size.width/2, self.superview.frame.size.height*2);
            break;


        case kAnimateFromRight:
            newCenter = CGPointMake(self.superview.frame.size.width*2, self.superview.frame.size.height/2);
            break;


        case kAnimateFromLeft:
            newCenter = CGPointMake(-1*(self.superview.frame.size.width/2), self.superview.frame.size.height/2);
            break;


        default:
            newCenter = CGPointMake(self.superview.frame.size.width/2, -1*(self.superview.frame.size.height/2));
            break;
    }

    [UIView animateWithDuration:duration animations:^{
        self.center = newCenter;
    } completion:^(BOOL finished) {
        [self removeFromSuperview];
        if(completion)
            completion();
    }];
}

- (void)removeFromSuperview:(void (^)(void))animations animationDirection:(AnimationDirection)animationDirection duration:(NSTimeInterval)duration completion:(void (^)(void))completion{
    CGPoint newCenter;
    switch (animationDirection) {
        case kAnimateFromTop:
            newCenter = CGPointMake(self.superview.frame.size.width/2, -1*(self.superview.frame.size.height));
            break;

        case kAnimateFromBottom:
            newCenter = CGPointMake(self.superview.frame.size.width/2, self.superview.frame.size.height*2);
            break;


        case kAnimateFromRight:
            newCenter = CGPointMake(self.superview.frame.size.width*2, self.superview.frame.size.height/2);
            break;


        case kAnimateFromLeft:
            newCenter = CGPointMake(-1*(self.superview.frame.size.width/2), self.superview.frame.size.height/2);
            break;


        default:
            newCenter = CGPointMake(self.superview.frame.size.width/2, -1*(self.superview.frame.size.height/2));
            break;
    }

    [UIView animateWithDuration:duration animations:^{
        if(animations)
            animations();
        self.center = newCenter;
    } completion:^(BOOL finished) {
        [self removeFromSuperview];
        if(completion)
            completion();
    }];
}

- (void)slideView:(AnimationDirection)animationDirection duration:(NSTimeInterval)duration completion:(void (^)(void))completion{
    //CGPoint newCenter = CGPointMake((self.frame.size.width/2)+self.frame.origin.x, (self.frame.size.height/2)+self.frame.origin.y);

    CGPoint newCenter;
    switch (animationDirection) {
        case kAnimateFromTop:
            newCenter = CGPointMake(self.superview.frame.size.width/2, -1*(self.superview.frame.size.height));
            break;

        case kAnimateFromBottom:
            newCenter = CGPointMake(self.superview.frame.size.width/2, self.superview.frame.size.height*2);
            break;


        case kAnimateFromRight:
            newCenter = CGPointMake(self.superview.frame.size.width*2, self.superview.frame.size.height/2);
            break;


        case kAnimateFromLeft:
            newCenter = CGPointMake(-1*(self.superview.frame.size.width/2), self.superview.frame.size.height/2);
            break;


        default:
            newCenter = CGPointMake(self.superview.frame.size.width/2, -1*(self.superview.frame.size.height/2));
            break;
    }

    [UIView animateWithDuration:duration animations:^{
        self.center = newCenter;
    } completion:^(BOOL finished) {
        if(completion)
            completion();
    }];
}


#pragma mark - Get SubView

- (void) addSubviewToBack:(UIView*)view {
    [self addSubview:view];
    [self sendSubviewToBack:view];
}

- (NSInteger)subviewIndex {
    if (self.superview == nil) {
        return NSNotFound;
    }
    return [self.superview.subviews indexOfObject:self];
}

- (UIView *)superviewWithClass:(Class)aClass {
    return [self superviewWithClass:aClass strict:NO];
}

- (UIView *)superviewWithClass:(Class)aClass strict:(BOOL)strict {
    UIView *view = self.superview;

    while(view) {
        if(strict && [view isMemberOfClass:aClass]) {
            break;
        }
        else if(!strict && [view isKindOfClass:aClass]) {
            break;
        }
        else {
            view = view.superview;
        }
    }
    return view;
}

- (UIView*)descendantOrSelfWithClass:(Class)aClass {
    return [self descendantOrSelfWithClass:aClass strict:NO];
}

- (UIView *)descendantOrSelfWithClass:(Class)aClass strict:(BOOL)strict {
    if (strict && [self isMemberOfClass:aClass]) {
        return self;
    }
    else if (!strict && [self isKindOfClass:aClass]) {
        return self;
    }

    for (UIView* child in self.subviews) {
        UIView* viewWithClass = [child descendantOrSelfWithClass:aClass strict:strict];

        if (viewWithClass != nil) {
            return viewWithClass;
        }
    }
    return nil;
}

- (void)removeAllSubviews {
    [self.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
}

- (void)bringToFront {
    [self.superview bringSubviewToFront:self];
}

- (void)sendToBack {
    [self.superview sendSubviewToBack:self];
}

- (void)bringOneLevelUp {
    NSInteger currentIndex = self.subviewIndex;
    [self.superview exchangeSubviewAtIndex:currentIndex withSubviewAtIndex:currentIndex+1];
}

- (void)sendOneLevelDown {
    NSInteger currentIndex = self.subviewIndex;
    [self.superview exchangeSubviewAtIndex:currentIndex withSubviewAtIndex:currentIndex-1];
}

- (BOOL)isInFront {
    return (self.superview.subviews.lastObject == self);
}

- (BOOL)isAtBack {
    return ([self.superview.subviews objectAtIndex:0] == self);
}

- (void)swapDepthsWithView:(UIView*)swapView {
    [self.superview exchangeSubviewAtIndex:self.subviewIndex withSubviewAtIndex:swapView.subviewIndex];
}

// view searching

- (UIView *)viewMatchingPredicate:(NSPredicate *)predicate {
    if ([predicate evaluateWithObject:self]) {
        return self;
    }
    for (UIView *view in self.subviews) {
        UIView *match = [view viewMatchingPredicate:predicate];
        if (match) {
            return match;
        }
    }
    return nil;
}

- (UIView *)viewWithTag:(NSInteger)tag ofClass:(Class)viewClass {
    return [self viewMatchingPredicate:[NSPredicate predicateWithBlock:^BOOL(UIView *evaluatedObject, __unused NSDictionary *bindings) {
        return [evaluatedObject tag] == tag && [evaluatedObject isKindOfClass:viewClass];
    }]];
}

- (UIView *)viewOfClass:(Class)viewClass {
    return [self viewMatchingPredicate:[NSPredicate predicateWithBlock:^BOOL(id evaluatedObject, __unused NSDictionary *bindings) {
        return [evaluatedObject isKindOfClass:viewClass];
    }]];
}

- (NSArray *)viewsMatchingPredicate:(NSPredicate *)predicate {
    return [self.subviews filteredArrayUsingPredicate:predicate];
}

- (NSArray *)viewsWithTag:(NSInteger)tag {
    NSPredicate *predicate = [NSPredicate predicateWithFormat: @"self.tag == %d", tag];
    return [self.subviews filteredArrayUsingPredicate:predicate];
}

- (NSArray *)viewsWithTag:(NSInteger)tag ofClass:(Class)viewClass {
    NSPredicate *predicate = [NSPredicate predicateWithFormat: @"self.tag == %d AND class == %@", tag,viewClass];
    return [self.subviews filteredArrayUsingPredicate:predicate];
}

- (NSArray *)viewsOfClass:(Class)viewClass {

    NSPredicate *predicate = [NSPredicate predicateWithFormat: @"class == %@", viewClass];
    return [self.subviews filteredArrayUsingPredicate:predicate];
}

- (UIView *)firstSuperviewMatchingPredicate:(NSPredicate *)predicate {
    if ([predicate evaluateWithObject:self]) {
        return self;
    }
    return [self.superview firstSuperviewMatchingPredicate:predicate];
}

- (UIView *)firstSuperviewOfClass:(Class)viewClass {
    return [self firstSuperviewMatchingPredicate:[NSPredicate predicateWithBlock:^BOOL(UIView *superview, __unused id bindings) {
        return [superview isKindOfClass:viewClass];
    }]];
}

- (UIView *)firstSuperviewWithTag:(NSInteger)tag1 {
    return [self firstSuperviewMatchingPredicate:[NSPredicate predicateWithBlock:^BOOL(UIView *superview, __unused id bindings) {
        return superview.tag == tag1;
    }]];
}

- (UIView *)firstSuperviewWithTag:(NSInteger)tag1 ofClass:(Class)viewClass {
    return [self firstSuperviewMatchingPredicate:[NSPredicate predicateWithBlock:^BOOL(UIView *superview, __unused id bindings) {
        return superview.tag == tag1 && [superview isKindOfClass:viewClass];
    }]];
}

- (BOOL)viewOrAnySuperviewMatchesPredicate:(NSPredicate *)predicate {
    if ([predicate evaluateWithObject:self]) {
        return YES;
    }
    return [self.superview viewOrAnySuperviewMatchesPredicate:predicate];
}

- (BOOL)viewOrAnySuperviewIsKindOfClass:(Class)viewClass {
    return [self viewOrAnySuperviewMatchesPredicate:[NSPredicate predicateWithBlock:^BOOL(UIView *superview, __unused id bindings) {
        return [superview isKindOfClass:viewClass];
    }]];
}

- (BOOL)isSuperviewOfView:(UIView *)view {
    return [self firstSuperviewMatchingPredicate:[NSPredicate predicateWithBlock:^BOOL(UIView *superview, __unused id bindings) {
        return superview == view;
    }]] != nil;
}

- (BOOL)isSubviewOfView:(UIView *)view {
    return [view isSuperviewOfView:self];
}

//responder chain

- (UIViewController *)viewController {
    id responder = self;

    while ((responder = [responder nextResponder])) {
        if ([responder isKindOfClass:[UIViewController class]]) {
            return responder;
        }
    }
    return nil;
}

- (UIView *)firstResponder {
    return [self viewMatchingPredicate:[NSPredicate predicateWithBlock:^BOOL(id evaluatedObject, __unused id bindings) {
        return [evaluatedObject isFirstResponder];
    }]];
}

@end
