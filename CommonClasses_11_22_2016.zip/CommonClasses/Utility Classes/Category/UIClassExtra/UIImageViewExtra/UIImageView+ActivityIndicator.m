//
//  UIImageView+ActivityIndicator.m
//  
//
//  Created on 23/11/15.
//
//

#import "UIImageView+ActivityIndicator.h"
#import "WebClient.h"
#import "CommonHeaders.h"


#define TAG_ACTIVITY_INDICATOR 156456

@implementation UIImageView (ActivityIndicator)

- (void)setImageWithURL:(NSString *)strUrl usingActivityIndicatorViewStyle:(UIActivityIndicatorViewStyle)activityIndicatorViewStyle {
    [self setImageWithURL:strUrl placeHolderImage:nil usingActivityIndicatorViewStyle:activityIndicatorViewStyle withCompletion:nil];
}

- (void)setImageWithURL:(NSString *)strUrl placeHolderImage:(UIImage *)placeholderImage usingActivityIndicatorViewStyle:(UIActivityIndicatorViewStyle)activityIndicatorViewStyle {
    [self setImageWithURL:strUrl placeHolderImage:placeholderImage usingActivityIndicatorViewStyle:activityIndicatorViewStyle withCompletion:nil];
}

- (void)setImageWithURL:(NSString *)strUrl placeHolderImage:(UIImage *)placeholderImage usingActivityIndicatorViewStyle:(UIActivityIndicatorViewStyle)activityIndicatorViewStyle withCompletion:(void (^)(UIImage *image, NSError *error))completion {
    if(![strUrl isValid]) {
        [self setImage:placeholderImage];
        if(completion) {
            completion(nil, nil);
        }
        return;
    }
    [self removeActivityIndicator];
    [self addActivityIndicatorWithStyle:activityIndicatorViewStyle];
    __weak typeof(self) weakSelf = self;
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:strUrl]];
    [request addValue:@"image/*" forHTTPHeaderField:@"Accept"];
    [self setImageWithURLRequest:request placeholderImage:placeholderImage success:^(NSURLRequest * _Nonnull request, NSHTTPURLResponse * _Nullable response, UIImage * _Nonnull image) {
        __strong __typeof__(weakSelf) strongSelf = weakSelf;
        [strongSelf setImage:image];
        [strongSelf removeActivityIndicator];
        if(completion) {
            completion(image,nil);
        }
    } failure:^(NSURLRequest * _Nonnull request, NSHTTPURLResponse * _Nullable response, NSError * _Nonnull error) {
        __strong __typeof__(weakSelf) strongSelf = weakSelf;
        [strongSelf removeActivityIndicator];
        if(completion) {
            completion(nil,error);
        }
    }];
}

- (void)addActivityIndicatorWithStyle:(UIActivityIndicatorViewStyle)activityStyle {
    UIActivityIndicatorView *activityIndicator = (UIActivityIndicatorView *)[self viewWithTag:TAG_ACTIVITY_INDICATOR];
    if (!activityIndicator) {
        activityIndicator = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:activityStyle];
        activityIndicator.center = CGPointMake(self.width/2, self.height/2);
        activityIndicator.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleRightMargin | UIViewAutoresizingFlexibleBottomMargin;
        activityIndicator.hidesWhenStopped = YES;
        activityIndicator.tag = TAG_ACTIVITY_INDICATOR;
        [self addSubview:activityIndicator];
    }
    [activityIndicator startAnimating];
}

- (void)removeActivityIndicator {
    UIActivityIndicatorView *activityIndicator = (UIActivityIndicatorView *)[self viewWithTag:TAG_ACTIVITY_INDICATOR];
    if (activityIndicator) {
        [activityIndicator removeFromSuperview];
    }
}

@end
