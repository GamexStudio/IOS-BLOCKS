//
//  UIImageView+ActivityIndicator.h
//  
//
//  Created on 23/11/15.
//
//

#import <UIKit/UIKit.h>

@interface UIImageView (ActivityIndicator)

- (void)setImageWithURL:(NSString *)strUrl usingActivityIndicatorViewStyle:(UIActivityIndicatorViewStyle)activityIndicatorViewStyle;

- (void)setImageWithURL:(NSString *)strUrl placeHolderImage:(UIImage *)placeholderImage usingActivityIndicatorViewStyle:(UIActivityIndicatorViewStyle)activityIndicatorViewStyle;

- (void)setImageWithURL:(NSString *)strUrl placeHolderImage:(UIImage *)placeholderImage usingActivityIndicatorViewStyle:(UIActivityIndicatorViewStyle)activityIndicatorViewStyle withCompletion:(void (^)(UIImage *image, NSError *error))completion;

@end
