//
//  UIButton+ActivityIndicator.h
//  
//
//  Created on 24/11/15.
//
//

#import <UIKit/UIKit.h>

@interface UIButton (ActivityIndicator)


- (void)setImageWithURL:(NSString *)strUrl forState:(UIControlState)controlState usingActivityIndicatorViewStyle:(UIActivityIndicatorViewStyle)activityIndicatorViewStyle;

- (void)setImageWithURL:(NSString *)strUrl withPlaceHolderImage:(UIImage *)placeholderImage forState:(UIControlState)controlState usingActivityIndicatorViewStyle:(UIActivityIndicatorViewStyle)activityIndicatorViewStyle ;

- (void)setImageWithURL:(NSString *)strUrl withPlaceHolderImage:(UIImage *)placeholderImage forState:(UIControlState)controlState usingActivityIndicatorViewStyle:(UIActivityIndicatorViewStyle)activityIndicatorViewStyle withCompletion:(void (^)(UIImage *image, NSError *error))completion;


@end
