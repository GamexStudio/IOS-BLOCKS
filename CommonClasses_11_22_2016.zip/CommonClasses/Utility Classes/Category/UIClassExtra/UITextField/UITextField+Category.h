

#import <UIKit/UIKit.h>

@interface UITextField (Category)

@property (nonatomic) IBInspectable NSInteger maxLength;
@property (nonatomic, strong) IBInspectable NSString *allowCharater;
@property (nonatomic, strong) IBInspectable NSString *disAllowCharater;
@property (nonatomic, strong) IBInspectable UIColor *placeholderColor;

@end
