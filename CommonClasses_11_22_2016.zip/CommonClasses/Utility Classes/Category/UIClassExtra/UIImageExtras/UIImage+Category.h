//
//  UIImageAdditions.h
//  Created by Devin Ross on 7/25/09.
//
/*

 tapku.com || http://github.com/devinross/tapkulibrary

 Permission is hereby granted, free of charge, to any person
 obtaining a copy of this software and associated documentation
 files (the "Software"), to deal in the Software without
 restriction, including without limitation the rights to use,
 copy, modify, merge, publish, distribute, sublicense, and/or sell
 copies of the Software, and to permit persons to whom the
 Software is furnished to do so, subject to the following
 conditions:

 The above copyright notice and this permission notice shall be
 included in all copies or substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
 HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 OTHER DEALINGS IN THE SOFTWARE.

 */

#import <UIKit/UIKit.h>

#define ROUNDEDRECT_PERCENTAGE 10

@interface UIImage (Category)

+ (UIImage *)imageWithColor:(UIColor *)color size:(CGSize)size;


+ (id)createRoundedRectImage:(UIImage *)image size:(CGSize)size radius:(NSInteger)r;

+ (id)createRoundedRectImage:(UIImage *)image radius:(NSInteger)r;


+ (UIImage *)imageFromText:(NSString *)text;
+ (UIImage *)imageFromText:(NSString *)text font:(UIFont *)font size:(CGSize)size;

+ (UIImage*)imageWithImage:(UIImage *)image scaledToSize:(CGSize)newSize;


- (UIImage *) imageCroppedToRect:(CGRect)rect;

- (UIImage *) squareImage;


- (UIImage *) ImageFitInSize:(CGSize)size;

- (UIImage *) imageWithWaterMask:(UIImage *)mask inRect:(CGRect)rect;

- (UIImage *) imageWithStringWaterMark:(NSString *)markString inRect:(CGRect)rect color:(UIColor *)color font:(UIFont *)font;
- (UIImage *) imageWithStringWaterMark:(NSString *)markString atPoint:(CGPoint)point color:(UIColor *)color font:(UIFont *)font;



- (UIImage *) imageWithColor:(UIColor*)color inRect:(CGRect)rect;
//- (void) drawInRect:(CGRect)rect withImageMask:(UIImage *)mask;
//- (void) drawMaskedColorInRect:(CGRect)rect withColor:(UIColor*)color;


- (BOOL) writeImageToFileAtPath:(NSString *)aPath;

-(UIImage *)resizeImage:(CGRect)rect;

- (UIImage *) imageReSize:(CGSize)size;


- (UIImage *) imageRotatedByDegrees:(CGFloat)degrees;


- (UIImage *)convertToGrayScale;
- (UIImage *)imageWithBlackWhite;

+ (UIImage *)thumbnailFromVideoAtPath:(NSString *)path;

@end


@interface UIImage (Border)

- (UIImage *) imageWithColoredBorder:(NSUInteger)borderThickness borderColor:(UIColor *)color withShadow:(BOOL)withShadow;
- (UIImage *) imageWithTransparentBorder:(NSUInteger)thickness;

@end

@interface UIImage (MGProportionalFill)

typedef enum {
    MGImageResizeCrop,	// analogous to UIViewContentModeScaleAspectFill, i.e. "best fit" with no space around.
    MGImageResizeCropStart,
    MGImageResizeCropEnd,
    MGImageResizeScale	// analogous to UIViewContentModeScaleAspectFit, i.e. scale down to fit, leaving space around if necessary.
} MGImageResizingMethod;

- (UIImage *)imageToFitSize:(CGSize)size method:(MGImageResizingMethod)resizeMethod;
- (UIImage *)imageCroppedToFitSize:(CGSize)size; // uses MGImageResizeCrop
- (UIImage *)imageScaledToFitSize:(CGSize)size; // uses MGImageResizeScale

@end

@interface UIImage (Blur)
- (UIImage *)boxblurImageWithBlur:(CGFloat)blur;
@end

