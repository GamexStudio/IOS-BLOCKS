
#import "UITextView+Category.h"
#import <objc/runtime.h>

static const char *phTextView = "placeHolderTextView";

static NSString * const INZMaxLengthKey         = @"INZMaxLengthKey";
static NSString * const INZAllowCharacterKey    = @"INZAllowCharacterKey";
static NSString * const INZDisAllowCharacterKey = @"INZDisAllowCharacterKey";

@implementation UITextView (Category)

@dynamic maxLength;
@dynamic allowCharater;
@dynamic disAllowCharater;
@dynamic placeHolder;

- (void)addTextChangeObserver {
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UITextViewTextDidChangeNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(textViewTextDidChangeNotification:) name:UITextViewTextDidChangeNotification object:nil];
}

- (UITextView *)placeHolderTextView {
    return objc_getAssociatedObject(self, phTextView);
}

- (void)setPlaceHolderTextView:(UITextView *)placeHolderTextView {
    objc_setAssociatedObject(self, phTextView, placeHolderTextView, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

#pragma mark - Getter

- (NSInteger)maxLength
{
    NSValue *maxLengthValue = objc_getAssociatedObject(self, &INZMaxLengthKey);
    if (maxLengthValue) {
        NSInteger maxLength;
        [maxLengthValue getValue:&maxLength];
        return maxLength;
    }
    
    return NSIntegerMax;
}

- (NSString *)allowCharater {
    return objc_getAssociatedObject(self, &INZAllowCharacterKey);
}

- (NSString *)disAllowCharater {
    return objc_getAssociatedObject(self, &INZDisAllowCharacterKey);
}

#pragma mark - Setter

- (void)setMaxLength:(NSInteger)maxLength
{
    if (maxLength < 1) {
        maxLength = NSIntegerMax;
    }
    NSValue *value = [NSValue value:&maxLength withObjCType:@encode(NSInteger)];
    objc_setAssociatedObject(self, &INZMaxLengthKey, value, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    [self addTextChangeObserver];
}

- (void)setAllowCharater:(NSString *)allowCharater {
    if (allowCharater.length > 0) {
        objc_setAssociatedObject(self, &INZAllowCharacterKey, allowCharater, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
        [self addTextChangeObserver];
    }
}

- (void)setDisAllowCharater:(NSString *)disAllowCharater {
    if (disAllowCharater.length > 0) {
        objc_setAssociatedObject(self, &INZDisAllowCharacterKey, disAllowCharater, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
        [self addTextChangeObserver];
    }
}

- (void)setPlaceHolder:(NSString *)placeHolder {
    UITextView *textView = [self placeHolderTextView];
    if (!textView) {
        [self addTextChangeObserver];
        textView = [[UITextView alloc] initWithFrame:self.bounds];
        textView.autoresizingMask = UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;
        textView.font = self.font;
//        textView.textContainerInset = UIEdgeInsetsZero;
//        textView.textContainer.lineFragmentPadding = 0;
        
        textView.backgroundColor = [UIColor clearColor];
        textView.textColor = [UIColor grayColor];
        textView.userInteractionEnabled = NO;
        textView.text = placeHolder;
        [self addSubview:textView];
        [self setPlaceHolderTextView:textView];
    }
    else {
        textView.text = placeHolder;
    }
    if([self.text length] > 0) {
        [textView setHidden:YES];
    }
}

- (void)textViewTextDidChangeNotification:(NSNotification *)notification {
    [[self placeHolderTextView] setHidden:[self.text length] > 0 ? YES : NO];
    
    if (self.allowCharater.length > 0) {
        NSCharacterSet *allowCharSet = [NSCharacterSet characterSetWithCharactersInString:self.allowCharater];
        NSCharacterSet *disAllowCharSet = [[NSCharacterSet characterSetWithCharactersInString:self.allowCharater] invertedSet];
        if ([[self lastCharacter] rangeOfCharacterFromSet:allowCharSet options:NSCaseInsensitiveSearch].location == NSNotFound) {
            self.text = [self.text stringByTrimmingCharactersInSet:disAllowCharSet];
        }
    }else if (self.disAllowCharater.length > 0) {
        NSCharacterSet *disAllowCharSet = [NSCharacterSet characterSetWithCharactersInString:self.disAllowCharater] ;
        if ([[self lastCharacter] rangeOfCharacterFromSet:disAllowCharSet options:NSCaseInsensitiveSearch].location != NSNotFound) {
            self.text = [self.text stringByTrimmingCharactersInSet:disAllowCharSet];
        }
    }
    NSInteger adaptedLength = MIN(self.text.length, self.maxLength);
    NSRange range = NSMakeRange(0, adaptedLength);
    
    self.text = [self.text substringWithRange:range];
}

- (NSString *)lastCharacter {
    if ([self.text length] > 0) {
        NSString *lastChar = [self.text substringFromIndex:[self.text length] - 1];
        return lastChar;
    }
    return @"";
}

@end
