//
//  DownloaderCell.swift
//  MultiVideoDownloaderSwift
//
//  Created by    on 29/04/18.
//  Copyright © 2018   . All rights reserved.
//

import UIKit

class DownloaderCell: UITableViewCell {
    @IBOutlet weak var IBBtn: UIButton!
    @IBOutlet weak var IBProgressView: UIProgressView!
    
    @IBOutlet weak var IBLblProgressLbl: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        IBProgressView.setProgress(0, animated: true)
    }
    

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
