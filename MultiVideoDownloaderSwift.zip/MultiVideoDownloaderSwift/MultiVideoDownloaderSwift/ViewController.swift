//
//  ViewController.swift
//  MultiVideoDownloaderSwift
//
//  Created by    on 29/04/18.
//  Copyright © 2018   . All rights reserved.
//

import UIKit
import AVFoundation
import MediaPlayer

class ViewController: UIViewController {

    @IBOutlet weak var IBTableView: UITableView!
    fileprivate let kCellIdentifier = "DownloaderCell"
    let arrFiles = ["http://techslides.com/demos/sample-videos/small.mp4", "http://techslides.com/demos/sample-videos/small.mp4", "http://0.s3.envato.com/h264-video-previews/80fad324-9db4-11e3-bf3d-0050569255a8/490527.mp4", "http://clips.vorwaerts-gmbh.de/big_buck_bunny.mp4"]
    var downloaded: [String: URLSessionDownloadTask] = [:]
    var progressValue: [CGFloat] = []
    var urlSession: URLSession?
    var selectedRow: Int = 0
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        urlSession = URLSession(configuration: .default, delegate: self, delegateQueue: OperationQueue.main)
        for _ in 0..<arrFiles.count {
            progressValue.append(0)
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        IBTableView.estimatedRowHeight = 44.0
        IBTableView.rowHeight = UITableViewAutomaticDimension
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func task(for index: Int) -> URLSessionDownloadTask? {
        return downloaded[String(index)]
    }
    
    func add(_ task:URLSessionDownloadTask, for index: Int) {
        downloaded[String(index)] = task
    }
    
    func index(for task: URLSessionDownloadTask?) -> Int {
        var index: Int = 0
        let keys = downloaded.keys
        for key in keys {
            if downloaded[key] == task {
                index = Int(key)!
                break
            }
        }
        return index
    }
    
    func setProgress(_ progress: CGFloat?, to cell: DownloaderCell?) {
        print("Float value \(progress)")
        cell?.IBLblProgressLbl.text = "\(progress!*100)%"
        cell?.IBProgressView.setProgress(Float(progress!) ?? 0, animated: true)
    }
    
    @objc func playAction(_ sender: UIButton) {
        let task = self.task(for: sender.tag)
    
        guard let playTask = task else {
            return
        }
        
        if playTask.state == .completed {
            let docDir = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0]
            let videoName = String(format: "vide%d.mp4",sender.tag)
            let dirUrl = URL(fileURLWithPath: (docDir as NSString).appendingPathComponent(videoName))
            print("Files is saved to \(dirUrl)")
            self.playVideo(dirUrl.path)
        }
        
        IBTableView.reloadData()
    }
    
    @objc func downloadAction(_ sender: UIButton) {
        var task = self.task(for: sender.tag)
        if !(task != nil) {
            let url = URL(string: arrFiles[sender.tag])
            task = self.urlSession?.downloadTask(with: url!)
            self.add(task!, for: sender.tag)
        }
        
        if task?.state == .running {
            task?.suspend()
        }else {
            task?.resume()
        }
        
        IBTableView.reloadData()
    }
}

extension ViewController: URLSessionDownloadDelegate, URLSessionTaskDelegate {
    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didFinishDownloadingTo location: URL) {
        let error: Error?
        
        let fileManager = FileManager()
        let docsDir = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0]
        let videoName = String(format: "vide%d.mp4",selectedRow)
        let dirUrl = URL(fileURLWithPath: (docsDir as NSString).appendingPathComponent(videoName))
        do {
            if ((try? fileManager.moveItem(at: location, to: dirUrl)) != nil) {
                print("File path \(dirUrl.path)")
            }else {
                print("File path \(dirUrl.path)")
            }
        }catch {
            
        }
        
        
    }
    
    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didWriteData bytesWritten: Int64, totalBytesWritten: Int64, totalBytesExpectedToWrite: Int64) {
        OperationQueue.main.addOperation {
            let percentage = ((CGFloat)(totalBytesWritten))/((CGFloat)(totalBytesExpectedToWrite))
            let index = self.index(for: downloadTask)
            self.progressValue[index] = CGFloat(percentage)
            self.IBTableView.reloadData()
        }
    }
    
    
    
}

extension ViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrFiles.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: kCellIdentifier, for: indexPath) as! DownloaderCell
         cell.selectionStyle = .none
        cell.IBBtn.tag = indexPath.row
        
        let task = self.task(for: indexPath.row)
        if let downloadedTask = task {
            
            if downloadedTask.state == .completed {
                cell.IBBtn.setTitle("Play", for: .normal)
                cell.IBBtn.addTarget(self, action: #selector(playAction(_:)), for: .touchUpInside)
                cell.IBBtn.tag = indexPath.row
                selectedRow = indexPath.row
            }else if downloadedTask.state == .running {
                cell.IBBtn.setTitle("Pause", for: .normal)
                cell.IBBtn.addTarget(self, action: #selector(downloadAction(_:)), for: .touchUpInside)
            }else {
                cell.IBBtn.setTitle("Resume", for: .normal)
                cell.IBBtn.addTarget(self, action: #selector(downloadAction(_:)), for: .touchUpInside)
            }
        }else {
            cell.IBBtn.setTitle("Download", for: .normal)
            cell.IBBtn.addTarget(self, action: #selector(downloadAction(_:)), for: .touchUpInside)
        }
        self.setProgress(progressValue[indexPath.row], to: cell)
        return cell
    }
    
    
}

extension ViewController {
    func playVideo(_ fileName: String) {
        let fileExists = FileManager.default.fileExists(atPath: fileName)
        
        if fileExists {
            let playerViewController = MPMoviePlayerViewController.init(contentURL: URL(fileURLWithPath: fileName))
            NotificationCenter.default.addObserver(self, selector: #selector(movieFinishedCallback(_:)), name: NSNotification.Name.MPMoviePlayerPlaybackDidFinish, object: playerViewController?.moviePlayer)
            self.view.addSubview((playerViewController?.view)!)
            
            
            let player = playerViewController?.moviePlayer
            player?.shouldAutoplay = true
            player?.movieSourceType = MPMovieSourceType.file
            player?.play()
        }
    }
    
    
    @objc func movieFinishedCallback(_ notification: NSNotification) {
        let player = notification.object as! MPMoviePlayerController
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name.MPMoviePlayerPlaybackDidFinish, object: player)
        player.stop()
        
        player.view.removeFromSuperview()
   
    }

}

