import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var IBTblView: UITableView!
    var collectionView: UICollectionView?
    let width = 50// Give your collectioview's width
    let array = ["one", "two", "three", "four", "five" ]
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        IBTblView.delegate = self
        IBTblView.dataSource = self
        
        registerCell()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func registerCell(){
        IBTblView.register(UINib(nibName: "TableViewCell", bundle: nil), forCellReuseIdentifier: "TableCell")
        
       
    }
}

extension ViewController: UITableViewDelegate, UITableViewDataSource{
    @available(iOS 2.0, *)
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return array.count
    }


    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TableCell", for: indexPath) as! TableViewCell
        collectionView = cell.IBCollectionView
        cell.IBCollectionView.delegate = self
        cell.IBCollectionView.dataSource = self
        if(array.count > 1){
            if(array.count > 5){
                if !( width*5 == Int(cell.IBCollectionView.frame.size.width)){
                    cell.IBCollectionView.frame.origin.x = cell.IBCollectionView.frame.origin.x - (cell.IBCollectionView.frame.size.width * 4)
                    cell.IBCollectionView.frame.size.width = cell.IBCollectionView.frame.size.width * 5
                }
            }else{
                
                if !(width*array.count == Int(cell.IBCollectionView.frame.size.width)){
                    cell.IBCollectionView.frame.origin.x = cell.IBCollectionView.frame.origin.x - (cell.IBCollectionView.frame.size.width * CGFloat(array.count-1))
                    cell.IBCollectionView.frame.size.width = cell.IBCollectionView.frame.size.width * CGFloat(array.count)
                }
                
                
            }
            
            print("collection width \(cell.IBCollectionView.frame.size.width)")
            
            cell.IBCollectionView.reloadData()
        }
        
        return cell
    }
}

extension ViewController : UICollectionViewDelegate, UICollectionViewDataSource{
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CollectionCell", for: indexPath) as! CollectionViewCell
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return array.count
    }
}
