import UIKit

class CollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var IBBtnCollection: UIButton!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
