//
//  ViewController.m
//  SearchPredicate
//
//  Created by Darshan on 15/02/17.
//  Copyright © 2017 Gamex. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()< UISearchBarDelegate>
{
    NSMutableArray *arrData;
    NSMutableArray *filteredContentList;
    BOOL isSearching;
}
@property (weak, nonatomic) IBOutlet UITableView *tblData;
@property (weak, nonatomic) IBOutlet UISearchBar *searchbar;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    arrData = [NSMutableArray arrayWithObjects:@"Darshan",@"jack",@"Steave",@"Jobs", nil];
    self.searchbar.delegate = self;
    filteredContentList = [[NSMutableArray alloc]init];
    // Do any additional setup after loading the view, typically from a nib.
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (isSearching){
        return [filteredContentList count];
    }else{
        return [arrData count];
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    

    static NSString *Celliidentifier = @"cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:Celliidentifier forIndexPath:indexPath];
    
    
    if (isSearching) {
        cell.textLabel.text = [filteredContentList objectAtIndex:indexPath.row];
    }
    else {
        cell.textLabel.text = [arrData objectAtIndex:indexPath.row];
    }
    return cell;

}

#pragma mark: - UISearchbar delegate methods
- (void)searchBarTextDidBeginEditing:(UISearchBar *)searchBar {
    isSearching = YES;
}

- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText {
    
    //Remove all objects first.
    [filteredContentList removeAllObjects];
    
    if([searchText length] != 0) {
        isSearching = YES;
        [self searchTableList];
    }
    else {
        isSearching = NO;
    }
    [self.tblData reloadData];
}


- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar {
    NSLog(@"Search Clicked");
    [self searchTableList];
}

- (void)searchTableList {
    NSString *searchString = _searchbar.text;
    
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"SELF contains[cd] %@",searchString];
    NSArray *filteredData = [arrData filteredArrayUsingPredicate:predicate];
    
    [filteredContentList addObjectsFromArray:filteredData];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
