//
//  AppDelegate.h
//  SearchPredicate
//
//  Created by Darshan on 15/02/17.
//  Copyright © 2017 Gamex. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (nonatomic) NSIndexPath *selectedIndex;
@end

