//
//  ViewController.h
//  SearchPredicate
//
//  Created by Darshan on 15/02/17.
//  Copyright © 2017 Gamex. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<UITableViewDelegate,UITableViewDataSource>


@end

