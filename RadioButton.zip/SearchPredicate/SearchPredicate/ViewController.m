//
//  ViewController.m
//  SearchPredicate
//
//  Created by Darshan on 15/02/17.
//  Copyright © 2017 Gamex. All rights reserved.
//

#import "ViewController.h"
#import "AppDelegate.h"

@interface ViewController ()< UISearchBarDelegate>
{
    NSMutableArray *arrData;
//    NSIndexPath *selectedIndex;

    
}
@property (weak, nonatomic) IBOutlet UITableView *tblData;


@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    arrData = [NSMutableArray arrayWithObjects:@"Darshan",@"jack",@"Steave",@"Jobs", nil];
   
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    
        return [arrData count];
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    

    static NSString *Celliidentifier = @"cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:Celliidentifier forIndexPath:indexPath];
    
    UIButton *radioBtn;
    radioBtn.tag = indexPath.row;
    radioBtn = (UIButton *)[cell viewWithTag:1];
    
    [radioBtn setImage:[UIImage imageNamed:@"ic_radio_button_unchecked"] forState:UIControlStateNormal];
    [radioBtn setImage:[UIImage imageNamed:@"ic_radio_button_checked"] forState:UIControlStateSelected];
    AppDelegate *appDelegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
    if ([indexPath isEqual:appDelegate.selectedIndex]) {
        radioBtn.selected = YES;
    } else {
        radioBtn.selected = NO;
    }
    
    UILabel *lbl;
    
    lbl = (UILabel *)[cell viewWithTag:2];
    lbl.text = [arrData objectAtIndex:indexPath.row];
    
        return cell;

}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    AppDelegate *appDelegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
    appDelegate.selectedIndex = indexPath;
    [tableView reloadData];
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
