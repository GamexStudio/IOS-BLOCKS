//
//  SampleViewController.h
//  SearchPredicate
//
//  Created by Darshan on 23/02/17.
//  Copyright © 2017 Gamex. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SampleViewController : UIViewController
- (IBAction)openAnotherVC:(id)sender;

@end
