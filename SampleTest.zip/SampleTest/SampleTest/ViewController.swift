//
//  ViewController.swift
//  SampleTest
//
//  Created by Akruti on 06/04/17.
//  Copyright © 2017 volansys. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        loadData()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func loadData(){
        let startDateString:String  = "01/01/2016"
        let endDateString:String = "04/03/2017"
        
        //        let startDateString:String  = "08/01/2016"
        //        let endDateString:String = "04/01/2018"
        
        let dateFormtter = DateFormatter()
        dateFormtter.dateFormat = "MM/dd/yyyy"
        
        let startDate = dateFormtter.date(from: startDateString)
        let endDate = dateFormtter.date(from: endDateString)
        
        var monthsStringArray = [String]()
        var monthsIntArray = [Int]()
        var monthsWithyear = [String]()
        dateFormtter.dateFormat = "MM"
        
        if let startYear: Int = startDate?.year(), let endYear = endDate?.year() {
            
            if let startMonth: Int = startDate?.month(), let endMonth: Int = endDate?.month() {
                for i in startYear...endYear {
                    for j in (i == startYear ? startMonth : 1)...(i < endYear ? 12 : endMonth) {
                        let monthTitle = dateFormtter.monthSymbols[j - 1]
                        monthsStringArray.append(monthTitle)
                        monthsIntArray.append(j)
                        
                        let monthWithYear = "\(monthTitle) \(i)"
                        monthsWithyear.append(monthWithYear)
                    }
                }
            }
            
        }
        
        print(monthsStringArray)
        print(monthsIntArray)
        print(monthsWithyear)
    }


}

extension Date {
    
    func month() -> Int {
        let month = Calendar.current.component(.month, from: self)
        return month
    }
    
    func year() -> Int {
        let year = Calendar.current.component(.year, from: self)
        return year
    }
}

