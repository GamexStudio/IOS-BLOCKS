//
//  ViewController.m
//  UITextFieldSearchbar
//

#import "ViewController.h"

@interface ViewController ()<UITableViewDelegate,UITableViewDataSource,UITextFieldDelegate>{
    
    NSMutableArray *arrData ;
    NSMutableArray *arrFilterSearch;
    BOOL isSearching;

}

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    arrFilterSearch = [[NSMutableArray alloc]init];
    arrData = [NSMutableArray arrayWithObjects:@"darshan",@"vyas",@"Jack",@"Steave",@"Jobs",@"Karan",@"aaakash",@"bob", nil];
    
    _txtSearch.delegate = self;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    if (isSearching){
        return [arrFilterSearch count];
    }else{
        return [arrData count];
    }
    
    
    
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{

    static NSString *Celliidentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:Celliidentifier forIndexPath:indexPath];
    
    if (isSearching){
        cell.textLabel.text = [arrFilterSearch objectAtIndex:indexPath.row];
    }else{
      cell.textLabel.text = [arrData objectAtIndex:indexPath.row];
    }
    
    
    
    return cell;
    
}


- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    [textField resignFirstResponder];
    return YES;
}

- (BOOL)textFieldShouldClear:(UITextField *)textField{
    arrFilterSearch = nil;
    arrFilterSearch = [NSMutableArray arrayWithArray:arrData];
    isSearching = NO;

    [_tblList reloadData];
    return YES;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
    NSString *searchKey = [_txtSearch.text stringByAppendingString:string];
    arrFilterSearch = nil;
    searchKey = [searchKey stringByReplacingCharactersInRange:range withString:@""];
    if (searchKey.length) {
        
        isSearching = YES;

        
        NSPredicate *pred = [NSPredicate predicateWithFormat:@"SELF CONTAINS[cd] %@", searchKey];

        
        
        arrFilterSearch = [NSMutableArray arrayWithArray:[arrData filteredArrayUsingPredicate:pred]];
    }
    else{
        isSearching = NO;

        arrFilterSearch = [NSMutableArray arrayWithArray:arrData];
        
    }
    
    [_tblList reloadData];
    return YES;
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
