
//
//  AppUtility.swift

//
//  Created by Henryp on 15/11/16.
//
//

import UIKit
import Foundation

import CoreLocation
import CoreTelephony




class AppUtility: NSObject,CLLocationManagerDelegate {

    /*
     NOTE: This class contains all the common methods
     */
    var arrUserRole : NSMutableArray = NSMutableArray()
//    var arrHomeMenu : Array<HomeMenu> = []

    var RSKImageCropedCompletion : ((UIImage?) -> Void)?
    var locationManager : CLLocationManager = CLLocationManager()
    var currentLocation : CLLocation = CLLocation(latitude: 0, longitude: 0)
    
    
    var notificationCount : Int  = 0
        
    
    
    
    //MARK: -
    static let shared = AppUtility()
    override init() {
        super.init()
        print("Initialize shared Utility")
        locationManager.requestWhenInUseAuthorization()
        locationManager.delegate = self
        locationManager.distanceFilter = 500 //Meter
        locationManager.startUpdatingLocation()
        intializeOnce()
    }
    
    func intializeOnce() -> Void {
        UIApplication.shared.statusBarStyle = .lightContent
        
        self.SETUP_SVPROGRESS()
        
        if #available(iOS 9.0, *) {
            let searchBarTextAttributes: [String : AnyObject] = [NSForegroundColorAttributeName: UIColor.white, NSFontAttributeName: UIFont.systemFont(ofSize: UIFont.systemFontSize)]
            UITextField.appearance(whenContainedInInstancesOf: [UISearchBar.self]).defaultTextAttributes = searchBarTextAttributes
        } else {
            // Fallback on earlier versions
        }
        
        
        
        let settings = UIUserNotificationSettings(types: [.alert , .sound], categories: nil)
        UIApplication.shared.registerUserNotificationSettings(settings)
        UIApplication.shared.registerForRemoteNotifications()
        
        
        print(K.imagesFolderPath)
        if FileManager.default.fileExists(atPath: K.imagesFolderPath) == false {            
            do {
               try FileManager.default.createDirectory(atPath: K.imagesFolderPath, withIntermediateDirectories: true, attributes: nil)
            } catch let error as NSError {
                NSLog("Unable to create directory \(error.debugDescription)")
            }            
        }
    }
    
    
    //MARK: - Instance Functions
    func SETUP_SVPROGRESS() {
        SVProgressHUD.setDefaultMaskType(SVProgressHUDMaskType.gradient)
        SVProgressHUD.setDefaultStyle(SVProgressHUDStyle.custom)
        SVProgressHUD.setBackgroundColor(UIColor.white)
        SVProgressHUD.setForegroundColor(UIColor.red)
    }
    
    
    //MARK: - CLocation Manager Delegate
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        if locations.count > 0 {
            currentLocation = locations[0]
        }
    }

    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        
    }

    //MARK: - 
    func countryCodeOfCellularProvider() -> String {
        let countryCode = CTTelephonyNetworkInfo().subscriberCellularProvider?.mobileNetworkCode
        print(countryCode ?? "")
        return countryCode ?? ""
    }
    
    
    //MARK: - Image Selection With Cropper
    func showImageSelectionOption(viewController: UIViewController, isCropEnable : Bool = false, completion: @escaping(_ image: UIImage?) -> Void) {
        UIAlertController.show(in: viewController, withTitle: nil, message: "Select Picture", preferredStyle: .actionSheet, cancelButtonTitle: "Cancel", destructiveButtonTitle: nil, otherButtonTitles: ["Take Photo", "Choose From Library"], popoverPresentationControllerBlock: nil, tap: { controller   , action  , buttonIndex in
            
            DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 0.5, execute: {
                if buttonIndex == 2 || buttonIndex == 3 {
                    let sourceT : UIImagePickerControllerSourceType = buttonIndex == 2 ? UIImagePickerControllerSourceType.camera : UIImagePickerControllerSourceType.photoLibrary                    
                    UIImagePickerController.image(with: sourceT, didFinish: {imagePicker, info in
                        let imgProfilePhoto : UIImage! = info?[UIImagePickerControllerOriginalImage] as? UIImage
                        if imgProfilePhoto != nil && isCropEnable == true {
                            self.openImageCropper(image: imgProfilePhoto, viewController: viewController, completion: { (croppedImage) in
                                completion(croppedImage)
                            })
                        }else if imgProfilePhoto != nil {
                            completion(imgProfilePhoto)
                        }
                    }, completion: nil)
                }
            })
        })
    }
    
    }
