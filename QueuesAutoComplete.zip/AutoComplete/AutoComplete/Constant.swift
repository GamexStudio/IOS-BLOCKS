//
//  Constant.swift

//
//  Created by Henryp on 15/11/16.
//
//

import UIKit
import Foundation




//public let BASE_URL = "http://192.168.10.63/foover/Source/development/PHP/api/web/v1/"
public let BASE_URL = "http://clientveb.net/clients/2017/foover/api/web/v1/"

struct K {
    
    static let FACEBOOK_KEY     = "1545113458893514"; // Also change in URL schema  Key is from Our test account
    static let ITUNE_APP_ID     = ""
    
    static let GoogleMapDefaultZoomLevel : Float = 12.0
    static let GoogleMapDefaultZoomLevelForLocationPicker : Float = 18.0
    
    
    //struct: Contains all the URLs
    struct URL {
        static let ITUNE_APP_URL       = "itms-apps://itunes.apple.com/app/id\(K.ITUNE_APP_ID)"
        
        
        static let LOGIN                        = BASE_URL + "user/login"
        static let SIGN_UP                      = BASE_URL + "user/signup"
        static let FORGOT_PASSWORD              = BASE_URL + "user/forgot-password"
        static let UPLOAD_IMAGE                 = BASE_URL + "master/uploadcommonfile"
        static let SOCIAL_LOGIN                 = BASE_URL + "user/social-login"
        static let ADD_DISH                     = BASE_URL + "cook/add-dish"
        static let GET_CATEGORY_LIST            = BASE_URL + "master/category-list"
        static let NOTIFICATION_SETTING         = BASE_URL + "master/notification-setting"
        static let CHANGE_LANGUAGE              = BASE_URL + "master/change-language"
        static let DISH_LIST                    = BASE_URL + "cook/dish-list"
        static let ACTIVE_INACTIVE              = BASE_URL + "cook/dish-statusupdate"
        static let ADD_DRIVER                   = BASE_URL + "user/add-driver"
        static let TAG_LIST                     = BASE_URL + "master/tag-list"
        static let DRIVER_LIST                  = BASE_URL + "cook/driverlist"
        
        
        
        
        
        
    }
    
    struct HomeMenuOption {
        static let CheckIn                  = "check_in"
        static let MessageBoard             = "message_board"
        static let Chat                     = "chat"
        static let LiveTiming               = "timing"
        
    }
    struct SettingOption {
        static let Title                    = "SettingTitle"
        static let Icon                     = "SettingImageIcon"
        
        
    }
    
    enum Setting : Int {
        case CreatePromoCode = 0
        case Revenues
        case OpenClose
        case DeliveryPickup
        case PickupAddress
        case ShippingAddress
        case EditProfile
        case ChangePassword
        case EmailNotification
    }
    
    enum PostType : Int {
        case PostLater = 0
        case PostNow 
    }
    
    struct Notification {
        static let UserRoleIconsDidDownload  = "UserRoleIconsDidDownloadNotification"
        
    }
    
    //struct: Contains All notification types
    struct NotificationType {
        static let NewRequest                   = ""
        
    }
    
    //struct: Contains Keys
    struct Key {
        static let LoggedInUser                 = "kLoggedInUserKey"
        static let DeviceToken                  = "kDeviceToken"
        
    }
    
   
    //struct: Contains Color used in application
    struct Color {
        static let redColor                     = UIColor(hexString: "f25e5a")
        static let greenColor                   = UIColor(hexString: "3c9b9a")
        static let grey1Color                   = UIColor(hexString: "777777")
        static let grey2Color                   = UIColor(hexString: "b3b5b5")
        static let grey3Color                   = UIColor(hexString: "ebebeb")
        static let grey4Color                   = UIColor(hexString: "f2f2f2")
    }
    
    
    //struct: Contains All the messages shown to user
   /* struct Message {
        static let OK                           = "OK"
        static let Cancel                       = "Cancel"
        static let YES                          = "Yes"
        static let NO                           = "No"
        static let CurrentLocationNotFound      = "Current location not found".localizedString()
        
        static let EmailID                      = "Email ID".localizedString()
        static let Password                     = "Password".localizedString()
        static let ForgotPassword               = "Forgot Password?".localizedString()
        static let SignIN                       = "Sign In".localizedString()
        static let Facebook                     = "Facebook".localizedString()
        static let Google                       = "Google".localizedString()
        static let DontHaveAccount              = "Don't have an account? SIGNUP".localizedString()
        static let OrLoginWith                  = "Or Login With".localizedString()
        
        
        static let FirstName                    = "First Name".localizedString()
        static let LastName                     = "Last Name".localizedString()
        static let MobileNumber                 = "Mobile Number".localizedString()
        static let ConfirmPassword              = "Confirm Password".localizedString()
        static let RefferalCode                 = "Referral Code (Optional)".localizedString()
        static let AgreeTermsConditions         = "Agree to the Terms and Conditions".localizedString()
        static let SignUp                       = "Sign Up".localizedString()
        static let AlreadyHaveAccount           = "Already have an account? SIGN IN".localizedString()
        
        static let AddNewAddress                = "Add New Address".localizedString()
        static let Title                        = "Title".localizedString()
        static let Address                      = "Address".localizedString()
        static let BuildingName                 = "Building Name".localizedString()
        static let AreaZone                     = "Area / Zone".localizedString()
        static let SpecialInstrcutions          = "Special Instructions".localizedString()
        static let AddNoW                       = "Add Now".localizedString()
        
        
        static let EnterTitleMessage                    = "Please enter title".localizedString()
        static let EnterAddressMessage                  = "Please enter address".localizedString()
        static let EnterBuildingNameMessage             = "Please enter building name".localizedString()
        static let EnterAreaZoneMessage                 = "Please enter area / zone".localizedString()
        static let EnterSpecialInstructionsMessage      = "Please enter special instructions".localizedString()
        
        static let EnterValidEmailMessage               = "Please enter valid email".localizedString()
        static let EnterPasswordMessage                 = "Please enter password".localizedString()
        static let EnterFirstNameMessage                = "Please enter first name".localizedString()
        static let EnterMobileNumberMessage             = "Please enter mobile number"
        static let SelectTermsConditionsMessage         = "Please select terms and conditions"
        static let EnterPasswordNotMatchMessage         = "Password and confirm password does not match"
        
        
        
        //add driver
        static let EnterDriverNameMessage                = "Please enter driver name".localizedString()
        static let EnterEmailMessage                      = "Please enter email".localizedString() 
        
        
    }
*/
    
    
    //struct: Contains all date and time format
    struct DateFormat {
        static let MessageBoardDate         = "dd/MM/yyyy"
        static let CreateEventDateTime      = "dd/MM/yyyy hh:mm a"
        
        static let time = "hh:mm a"
    }
    
    struct ImageFolderNameOnServer {
        static let ProfilePhoto = "profile_photo"
        static let DishImage   = "dish_photo"
        
        
    }
    
    public static var imagesFolderPath: String {
        return SF.documentsPath + "/Images"
    }
    
    public static func imagePath(imageName : String!) -> String {
        return  K.imagesFolderPath + "/" + imageName
    }
}
//struct: Contains social types
//struct SocialMediaType {
//    static let none = "none"
//    static let facebook = "Facebook"
//    static let google = "Google"
//}
enum SocialMediaType : Int {
    case none = 0
    case facebook = 1
    case google = 2
}

enum DishType : Int {
    case Inactive = 0
    case Active = 1
    case Delete = 2
}

struct LanguageType {
    static let english = "es"
    static let spanish = "sp"
}




