//
//  DishesViewController.swift
//  BiteCook
//
//  Created by rane on 04/05/17.
//
//

import UIKit

class DishesViewController: UIViewController,UITableViewDelegate,UITableViewDataSource{

    @IBOutlet weak var viewActive                          :UIView!
    @IBOutlet weak var viewNonActive                       :UIView!
    
    @IBOutlet weak var tblActiveDishList                   :UITableView!
    @IBOutlet weak var tblNonActiveDishList                :UITableView!
    
    @IBOutlet weak var segmentActivenonActive              :UISegmentedControl!

    @IBOutlet weak var lblActiveNoDataAvailable            :UILabel!
    @IBOutlet weak var lblNonActiveNoDataAvailable         :UILabel!
    
    
    //variable
    var arrActiveDishes                                    : [Dish] = []
    var arrNonActiveDishes                                 : [Dish] = []
    let width = 30

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        viewNonActive.isHidden = true
        // hide shadow
        UINavigationBar.appearance().shadowImage = UIImage()
        UINavigationBar.appearance().setBackgroundImage(UIImage(), for: .default)
        self.title = "Dishes"
        //set segment height and font size
        segmentActivenonActive.height = 40
        segmentActivenonActive.setTitleTextAttributes([NSFontAttributeName : UIFont.systemFont(ofSize: 16.0)], for: .normal)
        //set navigationbar font size and color
        self.navigationController?.navigationBar.titleTextAttributes = [ NSFontAttributeName: UIFont(name: kRegularFontName, size: 18.0)!, NSForegroundColorAttributeName: UIColor.white]

        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        lblActiveNoDataAvailable.isHidden = true
        lblNonActiveNoDataAvailable.isHidden = true
        getDishList()
    }
    
    
    //MARK: - Tableview Delegate & Datasource
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView .isEqual(tblActiveDishList)
        {
            return  arrActiveDishes.count
        }
        else{
            return  arrNonActiveDishes.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell=tableView.dequeueReusableCell(withIdentifier: "DishesCell", for: indexPath) as! DishesCell
        cell.selectionStyle = .none
        
        var dish: Dish!
        if tableView .isEqual(tblActiveDishList)
        {
            
            dish = arrActiveDishes[indexPath.row]
            cell.arrCategories = dish.arrCategory
            cell.lblDishName?.text = dish.title
            
            cell.lblDishPrice.text = String(dish.price)
            cell.imgViewDish.setImageWithURL(strUrl: dish.photo, placeHolderImage: nil, activityIndicatorViewStyle: ActivityIndicatorViewStyle.gray)

            
            if(dish.arrCategory.count > 1){
                
                if(dish.arrCategory.count > 5){
                    if !( width*5+(5*5) == Int(cell.categoryCollectionView.frame.size.width))
                    {
                        cell.categoryCollectionView.frame.origin.x = cell.categoryCollectionView.frame.origin.x - (cell.categoryCollectionView.frame.size.width * 4) - CGFloat(5*4)
                        
                        cell.categoryCollectionView.frame.size.width = cell.categoryCollectionView.frame.size.width * 5 + CGFloat(5*5)
                    }
                }else{
                    print("array count \(dish.arrCategory.count)")
                    print("width  with dish array \(width*dish.arrCategory.count)")
                    print("total width \(cell.categoryCollectionView.frame.width)")
                    
                    if !(width*dish.arrCategory.count+(5*dish.arrCategory.count) == Int(cell.categoryCollectionView.frame.size.width))
                    {
                        cell.categoryCollectionView.frame.origin.x = cell.categoryCollectionView.frame.origin.x - (cell.categoryCollectionView.frame.size.width * CGFloat(dish.arrCategory.count-1)) - CGFloat(5*dish.arrCategory.count)
                        cell.categoryCollectionView.frame.size.width = cell.categoryCollectionView.frame.size.width * CGFloat(dish.arrCategory.count) + CGFloat(5*dish.arrCategory.count)
                    }
                    
                    
                }
                
                             //   print("collection width \(cell.categoryCollectionView.frame.size.width)")
                
//                cell.categoryCollectionView.reloadData()
            }
            
            
        }
        else{
            dish = arrNonActiveDishes[indexPath.row]
            cell.lblDishName?.text = dish.title
            
            cell.btnActive?.tag = indexPath.row
            cell.btnActive?.addTarget(self, action: #selector(btnActiveClick(_:)), for: .touchUpInside)
            cell.imgViewDish.setImageWithURL(strUrl: dish.photo, placeHolderImage: nil, activityIndicatorViewStyle: ActivityIndicatorViewStyle.gray)
        }
        
        
        
        return cell
        
    }
    
    
    // MARK: - IBAcation
    @IBAction func activeNonActiveClicked(_ sender: Any) {
        
        
        switch segmentActivenonActive.selectedSegmentIndex
        {
        case 0:

            self.viewNonActive.isHidden = true
            self.viewActive.isHidden = false
            self.tblActiveDishList.reloadData()
        case 1:
            self.viewNonActive.isHidden = false
            self.viewActive.isHidden = true
             self.tblNonActiveDishList.reloadData()
        default:
            break;
        }
    }

    
    
    // MARK: - Other methods
    
   
    
    
    
    
    // MARK: - webservice
    
    func getDishList() {
        
        
        
        _ = WebClient.requestWithUrl(url: K.URL.DISH_LIST, parameters: ["user_id":"14"]) { (response, error) in
            if error == nil {
                self.arrActiveDishes = []
                self.arrNonActiveDishes = []

                let dictData = response as! NSDictionary
                if let arrData : Array = dictData["data"] as? Array<[String : Any]>{
                    
                    
                    for dictAttribute in arrData {
                        let dishList =  Dish(dict: dictAttribute)
                        if dishList.status == 1
                        {
                            self.arrActiveDishes.append(dishList)
                        }
                        else{
                            self.arrNonActiveDishes.append(dishList)
                        }
                        
                    }
                    if(!(self.arrNonActiveDishes.count > 0))
                    {
                        self.lblNonActiveNoDataAvailable.isHidden = false;
                        
                    }
                    if(!(self.arrActiveDishes.count>0))
                    {
                        self.lblActiveNoDataAvailable.isHidden = false;
                    }
                    
                }
                
            self.tblActiveDishList.reloadData()
            self.tblNonActiveDishList.reloadData()
            }
            else {
               
            }
            
            
        }
    }
    
    func btnActiveClick(_ sender : UIButton) {
        print(sender.tag)
        
        var dish = Dish()
        dish = arrNonActiveDishes[sender.tag]
        
        _ = WebClient.requestWithUrl(url: K.URL.ACTIVE_INACTIVE, parameters: ["user_id":"14","dish_id":dish.ID,"status":DishType.Active.rawValue]) { (response, error) in
            
            if error == nil {
                let dictData = response as! NSDictionary
                self.getDishList()
            }
            else {
            
            }
        }
        
        
    }

    func deleteDish(dishId:Int) {
        
        // Create the alert controller
        let alertController = UIAlertController(title: "", message: "Are you sure you want to delete this dish", preferredStyle: .alert)
        let yesAction = UIAlertAction(title: "Yes", style: UIAlertActionStyle.default) {
            UIAlertAction in
            
            _ = WebClient.requestWithUrl(url: K.URL.ACTIVE_INACTIVE, parameters: ["user_id":"14","dish_id":dishId,"status":DishType.Delete.rawValue]) { (response, error) in
                if error == nil {
                    let dictData = response as! NSDictionary
                    self.getDishList()
                }
                else {
                   
                }
            }
            
        }

        let noAction = UIAlertAction(title: "No", style: UIAlertActionStyle.cancel) {
            UIAlertAction in
            NSLog("Cancel Pressed")
        }
        
        // Add the actions
        alertController.addAction(yesAction)
        alertController.addAction(noAction)
        
        // Present the controller
        self.present(alertController, animated: true, completion: nil)
//        _ = WebClient.requestWithUrl(url: K.URL.ACTIVE_INACTIVE, parameters: ["user_id":User.loggedInUser()!.ID,"dish_id":dishId,"status":DishType.Delete.rawValue]) { (response, error) in
//            if error == nil {
//                let dictData = response as! NSDictionary
//                self.getDishList()
//            }
//            else {
//                ISMessages.show(error?.localizedDescription)
//            }
//        }

        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewDidDisappear(_ animated: Bool) {
       
    }
   
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
