
//
//  UIImageView+ActivityIndicator.swift
//  WebClient-Swift
//
//  Created by Harry on 19/11/16.
//
//

import Foundation
import Alamofire
import AlamofireImage

var TAG_ACTIVITY_INDICATOR = 156456

public enum ActivityIndicatorViewStyle : Int {
    
    case whiteLarge
    
    case white
    
    case gray
    
    case none
}
extension UIImageView {
    
  
       
    func setImageWithURL(strUrl: String?, placeHolderImage: UIImage? = nil, activityIndicatorViewStyle: ActivityIndicatorViewStyle? = .white) {
        setImageWithURL(strUrl, placeHolderImage: placeHolderImage, activityIndicatorViewStyle: activityIndicatorViewStyle, completionBlock: nil)
    }
    
    func setImageWithURL(_ strUrl: String?, placeHolderImage: UIImage?, activityIndicatorViewStyle: ActivityIndicatorViewStyle?, completionBlock:((_ image: UIImage?, _ error: Error?) -> Void)?) {
        if let url = strUrl {
            if activityIndicatorViewStyle != .none {
                self.addActivityIndicator(activityStyle: activityIndicatorViewStyle!)    
            }
            
            Alamofire.request(url).responseImage { response in
                if let image = response.result.value {
                    self.image = image;
                    completionBlock?(image, nil)
                }
                else {
                    completionBlock?(nil, response.result.error)
                }
                self.removeActivityIndicator()
            }
        }
    }

    func addActivityIndicator(activityStyle: ActivityIndicatorViewStyle) {
        var activityIndicator = self.viewWithTag(TAG_ACTIVITY_INDICATOR) as? UIActivityIndicatorView
        if activityIndicator == nil {
            var indicatiorStyle :  UIActivityIndicatorViewStyle = .white
            switch activityStyle {
            case .white:
                indicatiorStyle = .white
                break
            case .whiteLarge:
                indicatiorStyle = .whiteLarge
                break
            case .gray:
                indicatiorStyle = .gray
                break
            default:
                indicatiorStyle = .white
                
            }
            activityIndicator = UIActivityIndicatorView(activityIndicatorStyle: indicatiorStyle)
            activityIndicator!.center = CGPoint(x: CGFloat(self.frame.size.width / 2), y: CGFloat(self.frame.size.height / 2))
            activityIndicator!.autoresizingMask = [.flexibleLeftMargin, .flexibleTopMargin, .flexibleRightMargin, .flexibleBottomMargin]
            activityIndicator!.hidesWhenStopped = true
            activityIndicator!.tag = TAG_ACTIVITY_INDICATOR
            self.addSubview(activityIndicator!)
        }
        activityIndicator?.startAnimating()
    }
    
    func removeActivityIndicator() {
        let activityIndicator = self.viewWithTag(TAG_ACTIVITY_INDICATOR) as? UIActivityIndicatorView
        if activityIndicator != nil{
            activityIndicator!.removeFromSuperview()
        }
    }
    
}

