//
//  Dish.swift
//  BiteCook
//
//  Created by Darshan V on 10/05/17.
//
//

import UIKit

class Dish: NSObject {

    var ID                   : Int! = 0
    var userId               : Int! = 0
    var title                : String?
    var ingredients          : String?
    var proteins             : Int! = 0
    var carbohydrates        : Int! = 0
    var price                : Int! = 0
    var photo                : String?
    var tag                  : String?
    var rating               : Float! = 0
    var status               : Int! = 0
    var timeInterval         : Double!
    var arrCategory          : Array<Categories> = []
    override init() {
        
    }
    
    convenience init(dict : [String : Any]) {
        self.init()
        self.ID                    = dict["dish_id"] as? Int
        self.userId                = dict["user_id"] as? Int
        self.title                 = dict["dish_title"] as? String
        self.ingredients           = dict["ingredients"] as? String
        self.proteins              = dict["proteins"] as? Int
        self.carbohydrates         = dict["carbohydrates"] as? Int
        self.price                 = dict["dish_price"] as? Int
        self.photo                 = dict["dish_photo"] as? String
        self.tag                   = dict["dish_tags"] as? String
        self.rating                = dict["dish_rating"] as? Float
        self.status                = dict["status"] as? Int
        self.timeInterval          = dict["created_date"] as! Double
        
        for dictCategory in dict["dish_category"] as? Array<[String: Any]> ?? [] {
            let dishCategory = Categories(dict: dictCategory)
            arrCategory.append(dishCategory)
            
        }
     
    }

    
}
