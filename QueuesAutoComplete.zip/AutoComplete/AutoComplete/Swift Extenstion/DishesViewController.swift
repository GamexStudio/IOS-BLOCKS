//
//  DishesViewController.swift
//  BiteCook
//
//  Created by rane on 04/05/17.
//
//

import UIKit

class DishesViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {

    @IBOutlet weak var viewActive                          :UIView!
    @IBOutlet weak var viewNonActive                       :UIView!
    
    @IBOutlet weak var tblActiveDishList                   :UITableView!
    

    
    

    //variable
    var arrActiveDishes                                    : [Dish] = []
    var arrNonActiveDishes                                 : [Dish] = []
    let width = 30

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
       
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        getDishList()
    }
    
    
    //MARK: - Tableview Delegate & Datasource
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
       
            return  arrActiveDishes.count
       
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell=tableView.dequeueReusableCell(withIdentifier: "DishesCell", for: indexPath) as! DishesCell
        cell.selectionStyle = .none
        
        var dish: Dish!
        
//            cell.categoryCollectionView.register(UINib(nibName: "CategoriesTypeCell", bundle: nil), forCellWithReuseIdentifier: "CategoriesTypeCell")
//            
            dish = arrActiveDishes[indexPath.row]
            cell.arrCategories = dish.arrCategory
            cell.lblDishName?.text = dish.title
            
           
            cell.imgViewDish.setImageWithURL(strUrl: dish.photo, placeHolderImage: nil, activityIndicatorViewStyle: ActivityIndicatorViewStyle.gray)
        
            if(dish.arrCategory.count > 1){
                if(dish.arrCategory.count > 5){
                    if !( width*5+(5*5) == Int(cell.categoryCollectionView.frame.size.width))
                    {
                        cell.categoryCollectionView.frame.origin.x = cell.categoryCollectionView.frame.origin.x - (cell.categoryCollectionView.frame.size.width * 4) - CGFloat(5*4)
                        
                        cell.categoryCollectionView.frame.size.width = cell.categoryCollectionView.frame.size.width * 5 + CGFloat(5*5)
                    }
                }else{
                    print("width  with dish array \(width*dish.arrCategory.count)")
                    print("total width \(cell.categoryCollectionView.frame.width)")
                    
                    if !(width*dish.arrCategory.count+(5*dish.arrCategory.count) == Int(cell.categoryCollectionView.frame.size.width))
                    {
                        cell.categoryCollectionView.frame.origin.x = cell.categoryCollectionView.frame.origin.x - (cell.categoryCollectionView.frame.size.width * CGFloat(dish.arrCategory.count-1)) - CGFloat(5*dish.arrCategory.count)
                        cell.categoryCollectionView.frame.size.width = cell.categoryCollectionView.frame.size.width * CGFloat(dish.arrCategory.count) + CGFloat(5*dish.arrCategory.count)
                    }
                    
                    
                }
                
//                print("collection width \(cell.categoryCollectionView.frame.size.width)")
                
                cell.categoryCollectionView.reloadData()
            }
            
            
        
        
        
        
        return cell
        
    }
    
    
    // MARK: - IBAcation
    
    
    // MARK: - Other methods
    
    
    
    
    
    // MARK: - webservice
    
    func getDishList() {
        
        _ = WebClient.requestWithUrl(url: "http://clientveb.net/clients/2017/foover/api/web/v1/cook/dish-list", parameters: ["user_id":"3"]) { (response, error) in
            if error == nil {
                self.arrActiveDishes = []
                self.arrNonActiveDishes = []

                let dictData = response as! NSDictionary
                if let arrData : Array = dictData["data"] as? Array<[String : Any]>{
                    
                    
                    for dictAttribute in arrData {
                        let dishList =  Dish(dict: dictAttribute)
                        //if dishList.status == 1
                        //{
                            self.arrActiveDishes.append(dishList)
//                        //}
//                        else{
//                            self.arrNonActiveDishes.append(dishList)
//                        }
                        
                    }
                }
                self.tblActiveDishList.reloadData()
          
            }
            else {
              
            }
            
            
        }
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
   
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
