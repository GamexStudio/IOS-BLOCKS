//
//  CatCollectionViewCell.swift
//  AutoComplete
//
//  Created by Darshan on 15/05/17.
//  Copyright © 2017 Gamex. All rights reserved.
//

import UIKit

class CatCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var image: UIImageView!
}
