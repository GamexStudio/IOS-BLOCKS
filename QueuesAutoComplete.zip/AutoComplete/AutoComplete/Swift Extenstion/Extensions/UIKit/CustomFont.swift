//
//  CustomFont.swift
//  TrackReport
//
//  Created by Henryp on 29/03/17.
//
//

import UIKit


var kRegularFontName        = "HelveticaNeue"
var kLightFontName          = "HelveticaNeue"
var kSemiboldFontName       = "HelveticaNeue"
var kBoldFontName           = "HelveticaNeue-Bold"
var kCondensedBoldName      = "HelveticaNeue-CondensedBold"


func fontNameFromType(fontType : String) -> String {
    switch fontType.lowercased() {
    case "regular":
        return kRegularFontName
    case "bold":
        return kBoldFontName
    case "cond":
        return kCondensedBoldName
    default:
        return kRegularFontName
    }
}

extension UITextField {
    @IBInspectable var fontType : String?  {
        get {
            return self.font?.familyName
        }
        set {
            self.font = UIFont(name: fontNameFromType(fontType: newValue!), size: (self.font?.pointSize)!)
            
        }
    }
    
    @IBInspectable var returnButton : String!  {
        get {
            return "y"
        }
        set {
            if newValue.lowercased() == "y" || newValue.lowercased() == "yes" {
                let doneItem = UIBarButtonItem(barButtonSystemItem: .done, target: self, action: #selector(hideKeyboard))
                let flexableItem = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
                let toolbar = UIToolbar(frame: CGRect(x: 0, y: 0, w: UIScreen.main.bounds.size.width, h: 40))
                toolbar.tintColor = UIColor.darkGray
                toolbar.barTintColor = UIColor.lightGray
                toolbar.setItems([flexableItem,doneItem], animated: false)
                //toolbar.setBackgroundImage(UIImage(named: ""), forToolbarPosition: .any, barMetrics: .default)
                self.inputAccessoryView = toolbar
            }
        }
    }
    
    func hideKeyboard() -> Void {
        self.resignFirstResponder()
    }

}

extension UILabel {
    @IBInspectable var fontType : String?  {
        get {
            return self.font?.familyName
        }
        set {
            self.font = UIFont(name: fontNameFromType(fontType: newValue!), size: (self.font?.pointSize)!)
        }
    }
}

extension UITextView {
    @IBInspectable var fontType : String?  {
        get {
            return self.font?.familyName
        }
        set {
            self.font = UIFont(name: fontNameFromType(fontType: newValue!), size: (self.font?.pointSize)!)
        }
    }
    
    @IBInspectable var returnButton : String!  {
        get {
            return "y"
        }
        set {
            if newValue.lowercased() == "y" || newValue.lowercased() == "yes" {
                let doneItem = UIBarButtonItem(barButtonSystemItem: .done, target: self, action: #selector(hideKeyboard))
                let flexableItem = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
                let toolbar = UIToolbar(frame: CGRect(x: 0, y: 0, w: UIScreen.main.bounds.size.width, h: 40))
                toolbar.tintColor = UIColor.darkGray
                toolbar.barTintColor = UIColor.lightGray
                toolbar.setItems([flexableItem,doneItem], animated: false)
                //toolbar.setBackgroundImage(UIImage(named: ""), forToolbarPosition: .any, barMetrics: .default)
                self.inputAccessoryView = toolbar
            }
        }
    }
    
    func hideKeyboard() -> Void {
        self.resignFirstResponder()
    }
    
}

extension UIButton {
    @IBInspectable var fontType : String?  {
        get {
            return self.titleLabel?.font?.familyName
        }
        set {
            self.titleLabel?.font = UIFont(name: fontNameFromType(fontType: newValue!), size: (self.titleLabel?.font?.pointSize)!)
        }
    }
}

