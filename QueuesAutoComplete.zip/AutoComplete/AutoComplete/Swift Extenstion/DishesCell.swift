//
//  DishesCell.swift
//  FooverLoginDemo
//
//  Created by Darshan V on 03/05/17.
//  Copyright © 2017 Darshan V. All rights reserved.
//

import UIKit


class DishesCell: UITableViewCell,UICollectionViewDataSource, UICollectionViewDelegate {

    
    @IBOutlet weak var viewDataContainer : UIView!
    

    
    @IBOutlet weak var imgViewDish         : UIImageView!
  
    
    @IBOutlet weak var lblDishName         : UILabel!
    @IBOutlet weak var lblDishPrice        : UILabel!
    
    
    @IBOutlet weak var btnActive           : UIButton!
    
    
    @IBOutlet weak var categoryCollectionView  : UICollectionView!

    
    var arrCategories                : [Categories] = []

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        categoryCollectionView?.delegate = self
        categoryCollectionView?.dataSource = self
        
        categoryCollectionView.register(cellWithClass: CatCollectionViewCell.self)
        
    }

    //MARK: - Collectionview Methods
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        return arrCategories.count
        
    }
    
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CatCell", for: indexPath) as! CatCollectionViewCell
        
        
        let cat = arrCategories[indexPath.row]
//        cell.image.setImageWithURL(strUrl: cat.imageIconName)
        
        return cell
    }
    
    
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
