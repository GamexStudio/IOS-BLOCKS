//
//  CategoriesTypeCell.swift
//  AutoComplete
//
//  Created by Darshan on 14/05/17.
//  Copyright © 2017 Gamex. All rights reserved.
//

import UIKit

class CategoriesTypeCell: UICollectionViewCell {
    
    
    @IBOutlet weak var imageView: UIImageView!
    
}
