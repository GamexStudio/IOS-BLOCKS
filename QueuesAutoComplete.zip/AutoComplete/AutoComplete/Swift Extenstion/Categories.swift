//
//  Categories.swift
//  BiteCook
//
//  Created by Darshan V on 10/05/17.
//
//

import UIKit

public class Categories: NSObject {
    var ID                  : Int! = 0
    var title                : String?
    var imageIconName        : String?
    var isChecked            : Bool = false
    
    override init() {
        
    }
    
    
    convenience init(dict : [String : Any]) {
        self.init()
        self.ID                   = dict["category_id"] as? Int
        self.title                = dict["category_title"] as? String
        self.imageIconName        = dict["category_image"] as? String
        self.isChecked            = dict["is_checked"] as? Bool ?? false
    }
    
   

}
