//
//  QueuesCell.swift
//  AutoComplete
//
//  Created by Darshan on 17/05/17.
//  Copyright © 2017 Gamex. All rights reserved.
//

import UIKit

class QueuesCell: UITableViewCell {

    @IBOutlet weak var lblStatus           : UILabel!
    @IBOutlet weak var lblCount            : UILabel!
    
    @IBOutlet weak var imgUser1            : UIImageView!
    @IBOutlet weak var imgUser2            : UIImageView!
    @IBOutlet weak var imgUser3            : UIImageView!
    
    @IBOutlet weak var viewTop             : UIView!
    @IBOutlet weak var viewBottom          : UIView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
