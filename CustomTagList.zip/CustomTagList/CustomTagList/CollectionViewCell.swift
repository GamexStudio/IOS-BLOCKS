

import UIKit

class CollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var IBLblTagName: UILabel!
    @IBOutlet weak var IBBtnDelete: UIButton!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
