
import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var IBCollectionView: UICollectionView!
    @IBOutlet weak var IBTextField: UITextField!
    var tagVal: String?
    var tagList: [String]?
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        tagList = []
        IBCollectionView.delegate = self
        IBCollectionView.dataSource = self
        
        IBCollectionView.register(UINib(nibName: "CollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "CollectionCell")
        
        IBTextField.delegate = self
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

extension ViewController: UITextFieldDelegate{
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        tagVal = textField.text
        tagList?.append(tagVal!)
        textField.text = ""
        IBCollectionView.reloadData()
        return false
    }
}

extension ViewController: UICollectionViewDelegate, UICollectionViewDataSource,UICollectionViewDelegateFlowLayout{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
            return (tagList?.count)!
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CollectionCell", for: indexPath) as! CollectionViewCell
        
        cell.IBLblTagName.text = tagList?[indexPath.row]
        
        return cell
    }
}
