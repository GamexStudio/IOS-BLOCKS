
import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var IBCollectionView: UICollectionView!
    @IBOutlet weak var IBTextField: UITextField!
    var tagVal: String?
    var tagList: [String]?
    
    var tagLbl: UILabel?
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        tagList = []
        IBCollectionView.delegate = self
        IBCollectionView.dataSource = self
        
        IBCollectionView.register(UINib(nibName: "CollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "CollectionCell")
        
        IBTextField.delegate = self
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

extension ViewController: UITextFieldDelegate{
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        tagVal = textField.text
        tagList?.append(tagVal!)
        IBCollectionView.reloadData()
        textField.text = ""
        return false
    }
}

extension ViewController: UICollectionViewDelegate, UICollectionViewDataSource,UICollectionViewDelegateFlowLayout{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
            return (tagList?.count)!
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CollectionCell", for: indexPath) as! CollectionViewCell
        cell.IBLblTagName.text = tagList?[indexPath.row]
        let width = cell.IBLblTagName.text?.size(attributes: [NSFontAttributeName : UIFont(name: "Helvetica Neue", size: CGFloat(15))!]).width
        print("in cell \(width)")
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        let width = tagList?[indexPath.row].size(attributes: [NSFontAttributeName : UIFont(name: "Helvetica Neue", size: CGFloat(15))!]).width
        print(width)
        return CGSize(width: width! + 20, height: 35)
        
    }
}
