

import UIKit
import ASJTagsView


class ASJViewController: UIViewController {

    @IBOutlet weak var IBTextField: UITextField!
    @IBOutlet weak var IBScrollView: ASJTagsView!
    
    var tagVal: String?
    override func viewDidLoad() {
        super.viewDidLoad()
        
        IBTextField.delegate = self
        setup()
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func setup(){
        IBScrollView.tagColorTheme = .default
        IBScrollView.borderWidth = 1.0;
        IBScrollView.borderColor = UIColor.red
        handleTagBlocks()
        IBTextField.becomeFirstResponder()
    }
    
    func handleTagBlocks(){
        weak var weakSelf = self
        IBScrollView.deleteBlock = {(_ tagText: String, _ idx: Int) -> Void in
            var message: String = "You deleted: \(tagText)"
            weakSelf?.IBScrollView.deleteTag(at: idx)
        }
    }
}

extension ASJViewController: UITextFieldDelegate{
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        tagVal = textField.text
        IBScrollView.addTag(tagVal!)
        textField.text = nil
        return false
    }
}
