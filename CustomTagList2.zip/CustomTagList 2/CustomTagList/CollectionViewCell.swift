

import UIKit

class CollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var IBView: UIView!
    @IBOutlet weak var IBLblTagName: UILabel!
    @IBOutlet weak var IBBtnDelete: UIButton!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        //self.IBBtnDelete.layer.cornerRadius = 10.0
       // self.IBBtnDelete.layer.borderWidth = 1.0
        
        self.IBView.layer.cornerRadius = 20.0
        self.IBView.layer.borderColor = UIColor.red.cgColor
        self.IBView.layer.borderWidth = 1.0
    }

}
