import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var IBTextField: UITextField!
    @IBOutlet weak var IBTbl: UITableView!
    
    let array = ["Italian food","Mexican", "Burger", "Fastfood", "Tortillas", "Italian"]
    var resultArray: [String]?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        resultArray = []
        IBTextField.delegate = self
        
        IBTbl.delegate = self
        IBTbl.dataSource = self
        
        IBTbl.isHidden = true
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    //MARK: - Custom Method
    func searchString(string: String){
        
        let predicate = NSPredicate(format: "SELF beginswith[c] %@", string)
//        resultArray = [Any](arrayLiteral: array.filter { predicate.evaluate(with: $0) }) as? [String]
        resultArray = array.filter { predicate.evaluate(with: $0) }
        self.IBTbl.isHidden = false
        self.IBTbl.reloadData()
        print("resultArray \(resultArray)")
    }

}

extension ViewController: UITextFieldDelegate{
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        self.searchString(string: textField.text!)
        return true
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
        return true
    }
}

extension ViewController: UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell")
        cell?.textLabel?.text = resultArray?[indexPath.row]
        return cell!
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let text = resultArray?[indexPath.row]
        IBTextField.text = text
        IBTbl.isHidden = true
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return (resultArray?.count)!
    }
}
