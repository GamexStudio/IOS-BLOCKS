//
//  StudentCell.swift
//  DatabaseSample
//
//  Created by Darshan on 28/04/18.
//  Copyright © 2018 Darshan. All rights reserved.
//

import UIKit

class StudentCell: UITableViewCell {

    @IBOutlet weak var IBLblName: UILabel!
    @IBOutlet weak var IBLblMarks: UILabel!
    @IBOutlet weak var IBBtnEdit: UIButton!
    @IBOutlet weak var IBBtnDelete: UIButton!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

    
}
