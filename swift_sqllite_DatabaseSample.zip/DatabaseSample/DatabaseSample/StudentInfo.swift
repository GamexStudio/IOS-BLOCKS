//
//  StudentInfo.swift
//  DatabaseSample
//
//  Created by Darshan on 28/04/18.
//  Copyright © 2018 Darshan. All rights reserved.
//

import UIKit

class StudentInfo: NSObject {

    var RollNo: String = ""
    var Name: String = ""
    var Marks: String = ""
}
