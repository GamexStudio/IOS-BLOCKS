//
//  TopNavBarView.h
//  IndiaMLS
//
//  Created by Martin on 30/12/15.
//
//

#import <UIKit/UIKit.h>

#define kNotificationFontSize 10
#define kNotificationDefaultHeight 16
#define kNotificationLabelTag 2342

#define kTodayLabelFontSize 12
#define kTodayLabelDefaultWidth 26
#define kTodayLabelDefaultHeight 17
#define kTodayLabelTag 2343

#define kNavBarButtonWidth 35
#define kNavBarButtonHeight 44

@class Contacts;

@protocol TopNavBarViewDelegate <NSObject>
@optional
@end

typedef void(^TopSearchTextChangeBlock)(NSString *text);
typedef void(^TopSearchPressSearchBlock)(NSString *text);
typedef void(^TopSearchCancelSearchBlock)(void);

@interface TopNavBarView : UIViewController <UISearchBarDelegate> {
    IBOutlet UIView *leftBtnView;
    IBOutlet UIView *rightBtnView;
    
    IBOutlet UIView *searchView;
    IBOutlet UISearchBar *searchBar;
}

@property (nonatomic, assign) BOOL isSearchEnable;
@property (nonatomic, retain) IBOutlet UILabel *lblTitle;
@property (nonatomic, retain) id<TopNavBarViewDelegate> delegate;
@property (nonatomic, retain) IBOutlet UIImageView *imgdownarrow;
@property (nonatomic, retain) IBOutlet UIView *userDetails;
@property (nonatomic, retain) IBOutlet UIView *viewProfile;
@property (nonatomic, retain) IBOutlet UIImageView *imgViewUser;
@property (nonatomic, retain) IBOutlet UILabel *lblUserLetterImage;
@property (nonatomic, retain) IBOutlet UILabel *lblUserTitle;
@property (nonatomic, retain) IBOutlet UILabel *lblUserSubTitle;
@property (nonatomic, retain) IBOutlet UIView *viewCenterTitle;
@property (nonatomic, retain) IBOutlet UILabel *lblbalanceDetail;
@property (nonatomic, retain) IBOutlet UILabel *lblnavTitle;

+ (TopNavBarView *) getTopNavBarView;

- (void)setLeftBarButtons:(NSArray *)leftBarButtons;
- (void)setRightBarButtons:(NSArray *)rightBarButtons;

- (void)setLeftBarButtons:(NSArray *)leftBarButtons withButtonWidth:(CGFloat) width;
- (void)setRightBarButtons:(NSArray *)rightBarButtons withButtonWidth:(CGFloat) width;

- (void)setLeftBarButtons:(NSArray *)leftBarButtons withButtonSize:(CGSize) size;
- (void)setRightBarButtons:(NSArray *)rightBarButtons withButtonSize:(CGSize) size;

- (UIButton *)leftButtonAtIndex:(NSInteger)index;
- (UIButton *)rightButtonAtIndex:(NSInteger)index;

- (void) showUserDetails:(id)contacts;
- (void) hideUserDetails;

- (void) showSearchBar:(NSString *)searchText didTextChangeBlock:(TopSearchTextChangeBlock) textChangeBlock didPressSearchBlock:(TopSearchPressSearchBlock) pressSearchBlock didPressCancelSearchBlock:(TopSearchCancelSearchBlock) cancelSearchBlock;
- (void) hideSearchBar;
- (NSString *) searchText;
-(void)setLayoutForCenterTitle;
@end

@interface NSMutableArray (NavBarButtons)

- (void)addBarButtonWithTintColor:(UIColor *)color icon:(UIImage *)icon target:(id)tagret selector:(SEL) selector forControlEvents:(UIControlEvents)event;

- (void)addBarButtonWithTintColor:(UIColor *)color title:(NSString *)title target:(id)tagret selector:(SEL) selector forControlEvents:(UIControlEvents)event;

- (void)addBarButtonWithTintColor:(UIColor *)color icon:(UIImage *)icon target:(id)tagret selector:(SEL) selector forControlEvents:(UIControlEvents)event withNotification:(BOOL)addNotification;

- (void)addBarButtonWithTintColor:(UIColor *)color title:(NSString *)title icon:(UIImage *)icon target:(id)tagret selector:(SEL) selector forControlEvents:(UIControlEvents)event withNotification:(BOOL)addNotification;

- (void)addBarButtonForTodayDateWithTintColor:(UIColor *)color icon:(UIImage *)icon target:(id)tagret selector:(SEL) selector forControlEvents:(UIControlEvents)event;

- (void)addBarButtonWithTintColor:(UIColor *)color :(NSString *)title icon:(UIImage *)icon target:(id)tagret selector:(SEL) selector forControlEvents:(UIControlEvents)event withNotification:(BOOL)addNotification;

@end


@interface NSArray (NavBarButtons)

- (BOOL)sw_isEqualToButtons:(NSArray *)buttons;

@end

@interface UIButton (TopBarNotification)

- (void) setNavBarItemImage:(UIImage *)image;

- (void) setNotificationBadge:(NSInteger)count;

- (void) setTodayDate:(NSString *) strDate;

@end
